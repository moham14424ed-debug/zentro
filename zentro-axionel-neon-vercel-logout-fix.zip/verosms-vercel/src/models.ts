import { db, Queryable, Row } from './db';

// ───────────────────────────── users ─────────────────────────────

export class UserView {
  [k: string]: any;
  constructor(row: Row) {
    const { password_hash: _ph, role_name, role_display, agent_username, agent_name, ...rest } = row;
    Object.assign(this, rest);
    this.role = role_name ? { name: role_name, display_name: role_display } : null;
    this.agent = row.agent_id && agent_username ? { id: row.agent_id, username: agent_username, name: agent_name } : null;
    this.is_authenticated = true;
  }
  is_admin() {
    return this.role?.name === 'admin';
  }
  is_agent() {
    return this.role?.name === 'agent';
  }
  is_client() {
    return this.role?.name === 'client';
  }
  is_test() {
    return this.role?.name === 'test';
  }
  is_developer() {
    return this.role?.name === 'developer' || this.role?.name === 'admin';
  }
  to_dict() {
    return {
      id: this.id,
      username: this.username,
      email: this.email,
      name: this.name,
      company: this.company,
      country: this.country,
      role: this.role?.name ?? null,
      is_active: this.is_active,
      api_enabled: this.api_enabled,
      created_at: this.created_at ? this.created_at.toISOString() : null,
    };
  }
}

export const USER_SQL = `select u.*, r.name as role_name, r.display_name as role_display,
  a.username as agent_username, a.name as agent_name
  from users u left join roles r on r.id = u.role_id left join users a on a.id = u.agent_id`;

export const mkUser = (row: Row | null): UserView | null => (row ? new UserView(row) : null);

export async function getUserById(id: number, q: Queryable = db) {
  return mkUser(await q.one(`${USER_SQL} where u.id = $1`, [id]));
}
export async function getUserByUsername(username: string, q: Queryable = db) {
  return mkUser(await q.one(`${USER_SQL} where u.username = $1`, [username]));
}
export async function listUsers(whereSql: string, params: any[] = [], order = 'u.username') {
  const rows = await db.query(`${USER_SQL} ${whereSql ? 'where ' + whereSql : ''} order by ${order}`, params);
  return rows.map((r) => new UserView(r));
}
export const listAgents = () => listUsers(`r.name = 'agent'`);
export const getRoles = () => db.query(`select * from roles order by id`);
export const roleByName = (name: string, q: Queryable = db) => q.one(`select * from roles where name = $1`, [name]);

// ───────────────────────────── activity ─────────────────────────────

export async function logActivity(userId: number | null, action: string, details?: string | null, ip?: string | null, ua?: string | null, q: Queryable = db) {
  try {
    await q.exec(`insert into activity_logs (user_id, action, details, ip_address, user_agent) values ($1,$2,$3,$4,$5)`, [
      userId,
      action.slice(0, 100),
      details ?? null,
      ip ? ip.slice(0, 45) : null,
      ua ? ua.slice(0, 255) : null,
    ]);
  } catch (e) {
    console.error('[activity log failed]', (e as Error).message);
  }
}

// ───────────────────────────── relation loaders ─────────────────────────────

const uniq = (a: any[]) => [...new Set(a.filter((x) => x !== null && x !== undefined))];

/** Attach `row[as] = {id, username, name, email}` for each user id found in `row[idField]`. */
export async function attachUsers<T extends Row>(rows: T[], idField: string, as: string): Promise<T[]> {
  const ids = uniq(rows.map((r) => r[idField]));
  const map = new Map<number, Row>();
  if (ids.length) {
    for (const u of await db.query(`select id, username, name, email, is_active from users where id = any($1::int[])`, [ids])) map.set(u.id, u);
  }
  for (const r of rows) (r as any)[as] = r[idField] ? map.get(r[idField]) ?? null : null;
  return rows;
}

export async function attachRanges<T extends Row>(rows: T[], idField = 'range_id', as = 'sms_range'): Promise<T[]> {
  const ids = uniq(rows.map((r) => r[idField]));
  const map = new Map<number, Row>();
  if (ids.length) {
    for (const g of await db.query(`select id, name, prefix, country, operator, payout, daily_limit from sms_ranges where id = any($1::int[])`, [ids])) map.set(g.id, g);
  }
  for (const r of rows) (r as any)[as] = r[idField] ? map.get(r[idField]) ?? null : null;
  return rows;
}

export async function withRangeCounts<T extends Row>(ranges: T[], userId?: number | null): Promise<T[]> {
  const ids = ranges.map((r) => r.id);
  if (!ids.length) return ranges;
  const counts = await db.query(
    `select range_id,
       count(*) filter (where agent_id is null and client_id is null and is_active and status in ('available','reserved')) as available,
       count(*) filter (where agent_id is not null or client_id is not null) as reserved,
       count(*) filter (where status = 'test_pool') as test_pool,
       count(*) as total
     from sms_numbers where range_id = any($1::int[]) group by range_id`,
    [ids],
  );
  const cm = new Map(counts.map((c) => [c.range_id, c]));
  let todayMap = new Map<number, number>();
  if (userId) {
    const rows = await db.query(
      `select range_id, count(*) as n from sms_numbers
       where range_id = any($1::int[]) and (agent_id = $2 or client_id = $2) and assigned_at >= $3
       group by range_id`,
      [ids, userId, new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate()))],
    );
    todayMap = new Map(rows.map((r) => [r.range_id, r.n]));
  }
  for (const r of ranges as any[]) {
    const c = cm.get(r.id);
    r.available_count = c?.available ?? 0;
    r.reserved_count = c?.reserved ?? 0;
    r.test_pool_count = c?.test_pool ?? 0;
    r.number_count = c?.total ?? 0;
    r.today_taken = todayMap.get(r.id) ?? 0;
  }
  return ranges;
}

/** Numbers with their range / client / agent objects (as the Jinja templates expect). */
export async function hydrateNumbers<T extends Row>(rows: T[], opts: { received?: boolean } = {}): Promise<T[]> {
  await attachRanges(rows, 'range_id', 'sms_range');
  await attachUsers(rows, 'client_id', 'client');
  await attachUsers(rows, 'agent_id', 'agent');
  if (opts.received && rows.length) {
    const ids = rows.map((r) => r.id);
    const cnt = await db.query(`select number_id, count(*) as n from sms_cdr where sms_type = 'received' and number_id = any($1::int[]) group by number_id`, [ids]);
    const m = new Map(cnt.map((c) => [c.number_id, c.n]));
    for (const r of rows as any[]) r.received_count = m.get(r.id) ?? 0;
  }
  return rows;
}

export async function hydrateCdrs<T extends Row>(rows: T[]): Promise<T[]> {
  await attachRanges(rows, 'range_id', 'range_info');
  const ids = uniq(rows.map((r) => r.number_id));
  const map = new Map<number, Row>();
  if (ids.length) {
    for (const n of await db.query(`select id, number, agent_id from sms_numbers where id = any($1::int[])`, [ids])) map.set(n.id, n);
  }
  const numbers = [...map.values()];
  await attachUsers(numbers, 'agent_id', 'agent');
  for (const r of rows as any[]) r.sms_number = r.number_id ? map.get(r.number_id) ?? null : null;
  return rows;
}

// ───────────────────────────── wallet ─────────────────────────────

export async function agentTotalEarning(agentId: number, q: Queryable = db): Promise<number> {
  const v = await q.scalar(`select coalesce(sum(case when client_id is not null then client_payout else agent_payout end), 0) from sms_cdr where user_id = $1`, [agentId]);
  return Number(v) || 0;
}
export async function agentWithdrawn(agentId: number, q: Queryable = db) {
  return Number(await q.scalar(`select coalesce(sum(amount),0) from withdrawal_requests where user_id=$1 and status in ('approved','paid')`, [agentId])) || 0;
}
export async function agentPending(agentId: number, q: Queryable = db) {
  return Number(await q.scalar(`select coalesce(sum(amount),0) from withdrawal_requests where user_id=$1 and status='pending'`, [agentId])) || 0;
}
const r4 = (n: number) => Math.round(n * 10000) / 10000;
export async function agentBalance(agentId: number, q: Queryable = db) {
  return r4((await agentTotalEarning(agentId, q)) - (await agentWithdrawn(agentId, q)));
}
export async function agentAvailable(agentId: number, q: Queryable = db) {
  return r4((await agentBalance(agentId, q)) - (await agentPending(agentId, q)));
}
