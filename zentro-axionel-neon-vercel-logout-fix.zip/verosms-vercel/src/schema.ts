import crypto from 'crypto';
import { db, tx } from './db';
import { config } from './config';
import { schemaSql } from './generated/assets';
import { hashPassword } from './auth';

export const SCHEMA_VERSION = '2026-10-28.3';

let ready: Promise<void> | null = null;

/** Creates / upgrades the schema once per cold start, then seeds roles and default accounts. */
export function ensureReady(): Promise<void> {
  if (!ready) {
    ready = init().catch((e) => {
      ready = null;
      throw e;
    });
  }
  return ready;
}

async function currentVersion(): Promise<string | null> {
  try {
    return (await db.scalar<string>(`select value from app_meta where key = 'schema_version'`)) ?? null;
  } catch (e: any) {
    if (e && e.code === '42P01') return null; // table does not exist yet
    throw e;
  }
}

async function init() {
  if ((await currentVersion()) !== SCHEMA_VERSION) {
    await tx(async (t) => {
      await t.exec('select pg_advisory_xact_lock(727274)');
      if ((await currentVersion()) === SCHEMA_VERSION) return; // another instance finished first
      await t.exec(schemaSql);
      await t.exec(
        `insert into app_meta (key, value) values ('schema_version', $1)
         on conflict (key) do update set value = excluded.value, updated_at = now()`,
        [SCHEMA_VERSION],
      );
    });
  }
  await seed();
  await ensureAxionelProvider();
}

async function ensureAxionelProvider() {
  if (!config.axionelUsername || !config.axionelPassword) return;
  await tx(async (t) => {
    await t.exec(`delete from providers where name <> 'Axionel'`);
    await t.exec(
      `insert into providers (name,url,ptype,username,password,fetch_interval,auth_mode,request_method,request_format,request_params,request_headers,response_path,number_field,sender_field,message_field,date_field,is_active)
       values ('Axionel',$1,'axionel',$2,$3,$4,'basic','GET','query',$5,'','','destination_addr','source_addr','short_message','start_stamp',true)
       on conflict (name) do update set url=excluded.url, ptype=excluded.ptype, username=excluded.username, password=excluded.password, fetch_interval=excluded.fetch_interval, auth_mode='basic', request_method='GET', request_format='query', request_params=excluded.request_params, request_headers='{}', response_path='', number_field='destination_addr', sender_field='source_addr', message_field='short_message', date_field='start_stamp', is_active=true, last_error=null`,
      [config.axionelUrl, config.axionelUsername, config.axionelPassword, config.axionelFetchInterval, JSON.stringify({'per-page':'100'})],
    );
  });
}

async function seed() {
  const roleRows = await db.query(`select id, name from roles`);
  const roles = new Map(roleRows.map((r) => [r.name, r.id]));
  const hasAdmin = await db.scalar(`select 1 from users u join roles r on r.id = u.role_id where r.name = 'admin' limit 1`);
  if (!hasAdmin && roles.get('admin')) {
    let pw = config.adminPassword;
    const generated = !pw;
    if (generated) pw = crypto.randomBytes(9).toString('base64url');
    const taken = await db.scalar(`select 1 from users where username = 'admin'`);
    if (!taken) {
      await db.exec(
        `insert into users (username, email, password_hash, role_id, is_active) values ('admin', 'admin@panel.com', $1, $2, true)
         on conflict do nothing`,
        [await hashPassword(pw), roles.get('admin')],
      );
      if (generated) console.warn(`[setup] Created admin account. Username: admin  Password: ${pw}  (set ADMIN_PASSWORD to choose your own)`);
      else console.warn('[setup] Created admin account "admin" with the password from ADMIN_PASSWORD.');
    }
  }
  if (roles.get('test')) {
    const testUser = await db.scalar(`select id from users where username = 'test'`);
    if (!testUser) {
      await db.exec(
        `insert into users (username, email, password_hash, role_id, name, company, agent_id, api_enabled, is_active) values ('test', 'test@panel.local', $1, $2, 'Test Account', 'ZENTRO Test', null, false, true) on conflict do nothing`,
        [await hashPassword(config.testPassword), roles.get('test')],
      );
    } else {
      await db.exec(`update users set role_id = $2, agent_id = null, api_enabled = false, name = 'Test Account', company = 'ZENTRO Test' where id = $1`, [testUser, roles.get('test')]);
      await db.exec(`update sms_numbers set client_id = null, agent_id = null, status = 'available', assigned_at = null where client_id = $1 and status <> 'test'`, [testUser]);
    }
  }
}
