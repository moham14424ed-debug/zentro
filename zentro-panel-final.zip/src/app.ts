import type { IncomingMessage, ServerResponse } from 'http';
import { Ctx, HttpError, dispatch } from './http';
import { config, missingConfig } from './config';
import { loadUser } from './auth';
import { ensureReady } from './schema';
import { renderTemplate } from './views';

import './routes/auth';
import './routes/main';
import './routes/admin';
import './routes/ranges';
import './routes/billing';
import './routes/provider';
import './routes/monitor';
import './routes/developer';
import './routes/api';
import './routes/cron';

const isApi = (c: Ctx) => c.path.startsWith('/api/');

/** Browsers always send Origin on cross-site POSTs: refuse state-changing requests that come from another site. */
function checkCsrf(c: Ctx) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(c.method)) return;
  if (isApi(c) && c.path !== '/api/tick') return; // token-authenticated API, no cookies involved
  const origin = c.req.headers.origin as string | undefined;
  const referer = c.req.headers.referer as string | undefined;
  const src = origin && origin !== 'null' ? origin : referer;
  if (!src) {
    if (c.session.uid) throw new HttpError(403, 'Missing Origin header');
    return;
  }
  let host = '';
  try {
    host = new URL(src).host;
  } catch {}
  if (host !== new URL(c.baseUrl).host) throw new HttpError(403, 'Cross-site request blocked');
}

export async function handle(req: IncomingMessage, res: ServerResponse) {
  await dispatch(req, res, {
    before: async (c) => {
      if (c.path === '/healthz') return c.jsonOut({ ok: true });
      const missing = missingConfig();
      if (missing.length) {
        c.html(renderTemplate(c, 'errors/setup.html', { missing }), 503);
        return;
      }
      checkCsrf(c);
      try {
        await ensureReady();
      } catch (e) {
        console.error('[startup]', e);
        throw new HttpError(503, 'Database unavailable');
      }
      await loadUser(c);
    },
    onError: (c, err) => {
      const status = err instanceof HttpError ? err.status : 500;
      if (!(err instanceof HttpError)) console.error(`[error] ${c.method} ${c.path}`, err);
      if (isApi(c)) return c.jsonOut({ error: status === 404 ? 'Not found' : status === 500 ? 'Internal error' : String((err as Error).message) }, status);
      const msg = status === 503 ? 'The database is not reachable. Check DATABASE_URL (use the Supabase pooler string) and try again.' : status === 403 ? 'Request blocked.' : status === 405 ? 'Method not allowed.' : 'Something went wrong.';
      c.html(renderTemplate(c, status === 404 ? 'errors/404.html' : 'errors/error.html', { status, message: msg }), status);
    },
  });
}
void config;
