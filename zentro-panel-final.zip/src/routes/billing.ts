import { GET, POST, ANY, urlFor } from '../http';
import { db, tx } from '../db';
import { render } from '../views';
import { adminRequired, agentRequired } from '../auth';
import { agentAvailable, agentBalance, agentPending, attachUsers, listAgents, logActivity } from '../models';
import { addDays, makePagination, pageParams, startOfUtcDay } from '../util';
import { paginate, Where } from '../page';

// ───────────────────────── agent ─────────────────────────

ANY('billing.bank_accounts', '/agent/BankAccounts', agentRequired, async (c) => {
  if (c.method === 'POST') {
    const f = c.form;
    const action = f.get('action');
    if (action === 'add') {
      const method = f.str('method'), details = f.str('account_details');
      if (!method || !details) c.flash('Method and account details are required.', 'danger');
      else {
        await db.exec(`insert into agent_bank_accounts (agent_id, method, label, account_details) values ($1,$2,$3,$4)`, [c.user.id, method.slice(0, 30), f.str('label').slice(0, 100), details]);
        c.flash('Account added successfully!', 'success');
      }
    } else if (action === 'edit') {
      const n = await db.exec(
        `update agent_bank_accounts set method = coalesce(nullif($3,''), method), label = $4, account_details = coalesce(nullif($5,''), account_details) where id = $1 and agent_id = $2`,
        [f.int('account_id'), c.user.id, f.str('method').slice(0, 30), f.str('label').slice(0, 100), f.str('account_details')],
      );
      c.flash(n ? 'Account updated successfully!' : 'Account not found.', n ? 'success' : 'danger');
    } else if (action === 'delete') {
      const n = await db.exec(`delete from agent_bank_accounts where id = $1 and agent_id = $2`, [f.int('account_id'), c.user.id]);
      if (n) c.flash('Account deleted.', 'success');
    }
    return c.redirect(urlFor('billing.bank_accounts'));
  }
  const accounts = await db.query(`select * from agent_bank_accounts where agent_id = $1 order by created_at desc`, [c.user.id]);
  render(c, 'main/bank_accounts.html', { accounts });
});

ANY('billing.payment_requests', '/agent/PaymentRequests', agentRequired, async (c) => {
  if (c.method === 'POST') {
    const amount = c.form.float('amount', 0) ?? 0;
    const accountId = c.form.int('account_id');
    try {
      await tx(async (t) => {
        // serialise requests of the same agent so the balance cannot be overspent by double clicks
        await t.exec(`select pg_advisory_xact_lock($1)`, [c.user.id]);
        const acc = await t.one(`select * from agent_bank_accounts where id = $1 and agent_id = $2`, [accountId, c.user.id]);
        const available = await agentAvailable(c.user.id, t);
        if (!acc) throw new Error('Please select a valid account.');
        if (!(amount > 0)) throw new Error('Enter a valid amount.');
        if (amount > available) throw new Error(`Insufficient balance. Available: ${available}`);
        await t.exec(`insert into withdrawal_requests (user_id, amount, method, account_details, status) values ($1,$2,$3,$4,'pending')`, [c.user.id, amount, acc.method, `${acc.label || acc.method}: ${acc.account_details}`]);
      });
      c.flash('Payment request submitted successfully!', 'success');
    } catch (e: any) {
      c.flash(e.message, 'danger');
    }
    return c.redirect(urlFor('billing.payment_requests'));
  }
  const reqs = await paginate(`select * from withdrawal_requests where user_id = $1`, [c.user.id], 'created_at desc, id desc', c.query.int('page'), c.query.int('per_page'));
  const accounts = await db.query(`select * from agent_bank_accounts where agent_id = $1`, [c.user.id]);
  render(c, 'main/payment_requests.html', { requests: reqs, accounts, balance: await agentBalance(c.user.id), available: await agentAvailable(c.user.id), pending_locked: await agentPending(c.user.id) });
});

POST('billing.claim_daily_bonus', '/agent/DailyBonus/claim', agentRequired, async (c) => {
  const today = startOfUtcDay();
  const tomorrow = addDays(today, 1);
  try {
    await tx(async (t) => {
      await t.exec(`select pg_advisory_xact_lock($1)`, [c.user.id]);
      const count = Number(await t.scalar(`select count(*) from sms_cdr where user_id = $1 and sms_type = 'received' and created_at >= $2 and created_at < $3`, [c.user.id, today, tomorrow])) || 0;
      if (count < 10000) throw new Error(`You need 10,000 messages today. Current count: ${count}.`);
      const claim = await t.one(`insert into daily_bonus_claims (user_id, bonus_date, message_count, amount) values ($1,$2,$3,10) on conflict (user_id, bonus_date) do nothing returning id`, [c.user.id, today, count]);
      if (!claim) throw new Error('Today\'s $10 bonus has already been claimed.');
      await t.exec(`insert into wallet_adjustments (user_id, amount, kind, description) values ($1,10,'daily_bonus',$2)`, [c.user.id, `Daily bonus for ${count} received messages`]);
    });
    c.flash('$10 daily bonus added to your balance.', 'success');
  } catch (e: any) { c.flash(e.message, 'danger'); }
  c.redirect(urlFor('main.dashboard'));
});

GET('billing.credit_notes', '/agent/CreditNotes', agentRequired, async (c) => {
  const notes = await paginate(`select * from credit_notes where agent_id = $1`, [c.user.id], 'issued_at desc, id desc', c.query.int('page'), c.query.int('per_page'));
  render(c, 'main/credit_notes.html', { notes });
});

GET('billing.statements', '/agent/Statements', agentRequired, async (c) => {
  const p = pageParams(c.query.int('page'), c.query.int('per_page'), 25);
  const ledger = await db.query(
    `with l as (
       select created_at as d, 'OTP earning - ' || coalesce(nullif(destination,''), nullif(cli,''), 'number') as description,
              coalesce(case when client_id is not null then client_payout else agent_payout end, 0) as credit, 0::float8 as debit
         from sms_cdr where user_id = $1
       union all
       select coalesce(processed_at, created_at), 'Withdrawal (' || coalesce(method,'') || ') - ' || status, 0::float8, amount
         from withdrawal_requests where user_id = $1 and status in ('approved','paid')
       union all
       select created_at, coalesce(description, kind), case when amount > 0 then amount else 0 end, case when amount < 0 then -amount else 0 end
         from wallet_adjustments where user_id = $1)
     select d as date, description, credit, debit, round((sum(credit - debit) over (order by d, description rows unbounded preceding))::numeric, 4)::float8 as running_balance
     from l order by d desc, description limit ${p.limit} offset ${p.offset}`,
    [c.user.id],
  );
  const total = Number(await db.scalar(
    `select (select count(*) from sms_cdr where user_id = $1) + (select count(*) from withdrawal_requests where user_id = $1 and status in ('approved','paid'))`, [c.user.id])) || 0;
  const pg: any = makePagination(ledger, total, p.page, p.perPage, false);
  pg.pages = Math.max(1, pg.pages);
  pg.iter_pages = () => Array.from({ length: Math.min(pg.pages, 50) }, (_, i) => i + 1);
  render(c, 'main/statements.html', { pagination: pg, current_balance: await agentBalance(c.user.id) });
});

// ───────────────────────── admin ─────────────────────────

GET('billing.admin_bank_accounts', '/admin/BankAccounts', adminRequired, async (c) => {
  const w = new Where();
  const fa = c.query.int('fagent');
  if (fa) w.add('agent_id = ?', fa);
  const accounts = await paginate(`select * from agent_bank_accounts${w.sql}`, w.params, 'created_at desc, id desc', c.query.int('page'), c.query.int('per_page'));
  await attachUsers(accounts.items, 'agent_id', 'agent');
  render(c, 'admin/bank_accounts.html', { accounts, agents: await listAgents() });
});

ANY('billing.admin_balances', '/admin/Balances', adminRequired, async (c) => {
  if (c.method === 'POST') {
    const userId = c.form.int('user_id');
    const action = c.form.str('action');
    const amount = c.form.float('amount', 0) ?? 0;
    const user = await db.one(`select id, username from users where id = $1`, [userId]);
    if (!user) c.flash('User not found.', 'danger');
    else if (action === 'freeze' || action === 'unfreeze') {
      await db.exec(`insert into wallets (user_id, withdrawals_frozen) values ($1,$2) on conflict (user_id) do update set withdrawals_frozen=excluded.withdrawals_frozen, updated_at=now()`, [userId, action === 'freeze']);
      await logActivity(c.user.id, 'admin_balance_freeze', `${action} withdrawals for ${user.username}`, c.ip);
      c.flash(`${user.username} withdrawals ${action}d.`, 'success');
    } else if ((action === 'add' || action === 'subtract') && amount > 0) {
      const signed = action === 'add' ? amount : -amount;
      await db.exec(`insert into wallet_adjustments (user_id, amount, kind, description, created_by) values ($1,$2,'manual',$3,$4)`, [userId, signed, c.form.str('description').slice(0, 255) || (action === 'add' ? 'Admin credit' : 'Admin debit'), c.user.id]);
      await logActivity(c.user.id, 'admin_balance_adjustment', `${action} ${amount} for ${user.username}`, c.ip);
      c.flash(`Balance updated for ${user.username}.`, 'success');
    } else c.flash('Choose a valid action and amount.', 'danger');
    return c.redirect(urlFor('billing.admin_balances'));
  }
  const agents = await listAgents();
  const balances = [];
  for (const a of agents) balances.push({ user: a, balance: await agentBalance(a.id), frozen: !!(await db.scalar(`select withdrawals_frozen from wallets where user_id=$1`, [a.id])) });
  render(c, 'admin/balances.html', { balances });
});

ANY('billing.admin_payment_requests', '/admin/PaymentRequests', adminRequired, async (c) => {
  if (c.method === 'POST') {
    const id = c.form.int('request_id');
    const status = c.form.str('status');
    const back = (m: string, k: string) => { c.flash(m, k); return c.redirect(urlFor('billing.admin_payment_requests')); };
    if (!['approved', 'rejected', 'paid'].includes(status)) return back('Invalid status.', 'danger');
    const wr = await db.one(`select * from withdrawal_requests where id = $1`, [id]);
    if (!wr) return back('Request not found.', 'danger');
    if (wr.status === 'rejected' && status !== 'rejected') return back('A rejected request cannot be re-opened; ask the agent to submit a new one.', 'danger');
    await db.exec(`update withdrawal_requests set status=$2, admin_note=$3, processed_at=now() where id=$1`, [id, status, c.form.str('admin_note')]);
    await logActivity(c.user.id, 'admin_payment_request', `Request #${id} -> ${status}`, c.ip);
    return back(`Request #${id} marked as ${status}.`, 'success');
  }
  const w = new Where();
  const fs = c.query.str('fstatus');
  if (fs) w.add('status = ?', fs);
  const fa = c.query.int('fagent');
  if (fa) w.add('user_id = ?', fa);
  const requests = await paginate(`select * from withdrawal_requests${w.sql}`, w.params, 'created_at desc, id desc', c.query.int('page'), c.query.int('per_page'));
  await attachUsers(requests.items, 'user_id', 'user');
  const pending_count = await db.scalar(`select count(*) from withdrawal_requests where status = 'pending'`);
  render(c, 'admin/payment_requests.html', { requests, agents: await listAgents(), pending_count });
});

GET('billing.admin_credit_notes', '/admin/CreditNotes', adminRequired, async (c) => {
  const w = new Where();
  const fa = c.query.int('fagent');
  if (fa) w.add('agent_id = ?', fa);
  const notes = await paginate(`select * from credit_notes${w.sql}`, w.params, 'issued_at desc, id desc', c.query.int('page'), c.query.int('per_page'));
  await attachUsers(notes.items, 'agent_id', 'agent');
  render(c, 'admin/credit_notes.html', { notes, agents: await listAgents() });
});

POST('billing.admin_credit_note_mark_paid', '/admin/CreditNotes/<int:note_id>/mark-paid', adminRequired, async (c) => {
  const n = await db.exec(`update credit_notes set status = 'paid' where id = $1`, [c.params.note_id]);
  if (n) c.flash(`Credit Note #${c.params.note_id} marked as paid.`, 'success');
  c.redirect(urlFor('billing.admin_credit_notes'));
});
