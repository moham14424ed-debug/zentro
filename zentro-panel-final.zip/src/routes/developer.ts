import { GET, POST, ANY, urlFor, abort } from '../http';
import { db } from '../db';
import { render } from '../views';
import { devRequired } from '../auth';
import { logActivity } from '../models';

const TYPES = ['img', 'css', 'js', 'html'];
const slugOf = (name: string) => name.replace(/\.[^.]*$/, '').toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/^-+|-+$/g, '');
const withSlug = (rows: any[]) => rows.map((r) => ({ ...r, slug: slugOf(r.filename) }));
const list = (type: string) => db.query(`select * from static_assets where asset_type = $1 and is_active order by created_at desc`, [type]);

GET('dev.index', '/dev/', devRequired, async (c) => {
  const [imgs, csss, jss, htmls] = await Promise.all(TYPES.map(list));
  render(c, 'developer/index.html', { imgs, csss, jss, htmls: withSlug(htmls) });
});

ANY('dev.upload', '/dev/upload', devRequired, async (c) => {
  if (c.method === 'POST') {
    const f = c.form;
    const type = f.str('asset_type').toLowerCase();
    let filename = f.str('filename');
    const bad = (m: string) => { c.flash(m, 'danger'); return c.redirect(urlFor('dev.upload')); };
    if (!TYPES.includes(type)) return bad('Invalid asset type.');
    if (!filename) return bad('Filename is required.');
    filename = filename.replace(/[^\w.\- ]/g, '_').slice(0, 200);
    if (!filename.includes('.')) filename += { img: '.png', css: '.css', js: '.js', html: '.html' }[type];
    if (type === 'html') {
      const slug = slugOf(filename);
      if ((await list('html')).some((a) => slugOf(a.filename) === slug)) return bad(`An HTML page with slug "${slug}" already exists.`);
    }
    await db.exec(`insert into static_assets (uploader_id, asset_type, filename, title, description, content, is_active) values ($1,$2,$3,$4,$5,$6,true)`, [c.user.id, type, filename, f.str('title') || filename, f.str('description'), f.get('content', '')]);
    await logActivity(c.user.id, 'dev_upload', `Uploaded ${type}: ${filename}`, c.ip);
    c.flash(`✅ ${filename} uploaded successfully!`, 'success');
    return c.redirect(urlFor('dev.index'));
  }
  render(c, 'developer/upload.html', { default_type: c.query.get('type', 'html') });
});

ANY('dev.edit', '/dev/edit/<int:asset_id>', devRequired, async (c) => {
  const a = await db.one(`select * from static_assets where id = $1`, [c.params.asset_id]);
  if (!a) abort(404);
  if (c.method === 'POST') {
    await db.exec(`update static_assets set title=$2, description=$3, content=$4, is_active=$5 where id=$1`, [a!.id, c.form.str('title') || a!.title, c.form.str('description'), c.form.get('content', ''), c.form.bool('is_active')]);
    await logActivity(c.user.id, 'dev_edit', `Edited ${a!.asset_type}: ${a!.filename}`, c.ip);
    c.flash(`✅ ${a!.filename} updated.`, 'success');
    return c.redirect(urlFor('dev.index'));
  }
  render(c, 'developer/edit.html', { asset: { ...a, slug: slugOf(a!.filename) } });
});

POST('dev.delete', '/dev/delete/<int:asset_id>', devRequired, async (c) => {
  const a = await db.one(`delete from static_assets where id = $1 returning filename`, [c.params.asset_id]);
  if (!a) abort(404);
  await logActivity(c.user.id, 'dev_delete', `Deleted ${a!.filename}`, c.ip);
  c.flash(`Deleted ${a!.filename}.`, 'success');
  c.redirect(urlFor('dev.index'));
});

const serve = (type: string, mime: string) => async (c: any) => {
  const a = await db.one(`select content from static_assets where id = $1 and asset_type = $2 and is_active`, [c.params.asset_id, type]);
  if (!a) abort(404);
  c.setOut(200, a!.content || '', mime, { 'Cache-Control': 'public, max-age=60', 'X-Content-Type-Options': 'nosniff' });
};
GET('dev.serve_css', '/dev/serve/css/<int:asset_id>', serve('css', 'text/css; charset=utf-8'));
GET('dev.serve_js', '/dev/serve/js/<int:asset_id>', serve('js', 'application/javascript; charset=utf-8'));

GET('dev.pages_list', '/dev/pages/', devRequired, async (c) => render(c, 'developer/pages_list.html', { pages: withSlug(await list('html')) }));

/**
 * Public page rendered from DB content. The CSP `sandbox` header gives the page an opaque origin,
 * so scripts inside developer-authored pages can never read the panel's session or call its API.
 */
GET('dev.page_view', '/dev/pages/<slug>', async (c) => {
  const a = (await list('html')).find((x) => slugOf(x.filename) === c.params.slug);
  if (!a) abort(404);
  const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${String(a!.title || a!.filename).replace(/[<>&"]/g, '')}</title></head><body>${a!.content || ''}</body></html>`;
  c.setOut(200, html, 'text/html; charset=utf-8', { 'Content-Security-Policy': 'sandbox allow-scripts allow-forms allow-popups', 'X-Content-Type-Options': 'nosniff' });
});

GET('dev.api_assets', '/dev/api/assets', devRequired, async (c) => {
  const t = c.query.str('type') || 'html';
  const rows = TYPES.includes(t) ? await list(t) : [];
  c.jsonOut({ assets: rows.map((a) => ({ id: a.id, asset_type: a.asset_type, filename: a.filename, title: a.title, description: a.description, created_at: a.created_at?.isoformat?.() })) });
});
