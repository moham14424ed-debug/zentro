import crypto from 'crypto';
import { GET, POST, Ctx } from '../http';
import { config } from '../config';
import { db } from '../db';
import { pollDue } from '../fetchers';
import { runMaintenance } from '../services/jobs';
import { errMsg } from '../util';

const safeEq = (a: string, b: string) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

/** Vercel Cron sends `Authorization: Bearer $CRON_SECRET`; GitHub Actions / external pingers use the same header. */
function cronAuthorized(c: Ctx): boolean {
  if (!config.cronSecret) return false;
  const h = String(c.req.headers.authorization || '');
  const given = h.startsWith('Bearer ') ? h.slice(7) : String(c.query.get('secret') || '');
  return !!given && safeEq(given, config.cronSecret);
}

const handler = async (c: Ctx) => {
  if (!cronAuthorized(c)) return c.jsonOut({ error: config.cronSecret ? 'unauthorized' : 'CRON_SECRET is not configured' }, config.cronSecret ? 401 : 403);
  try {
    const poll = await pollDue(c.query.int('budget') ? Math.min(c.query.int('budget')! * 1000, 55000) : 50000);
    const maintenance = await runMaintenance(3600, c.query.has('force'));
    c.jsonOut({ ok: true, poll, maintenance });
  } catch (e) {
    c.jsonOut({ ok: false, error: errMsg(e) }, 500);
  }
};
GET('cron.run', '/api/cron/run', handler);
POST('cron.run_post', '/api/cron/run', handler);
// kept for the daily Vercel cron entry
GET('cron.daily', '/api/cron/daily', handler);

/**
 * Browser ticker: any logged-in page calls this every ~30 s. It polls the providers that are due
 * (each provider is claimed atomically, so many tabs never cause duplicate fetches).
 */
POST('cron.tick', '/api/tick', async (c) => {
  if (!c.user) return c.jsonOut({ ok: false }, 401);
  // cheap guard so N open tabs do not all hit the database for the due-check
  const due = await db.scalar(`select count(*) from providers where is_active and (last_fetch_at is null or last_fetch_at < timezone('utc', now()) - make_interval(secs => greatest(fetch_interval, $1::int)))`, [config.minFetchInterval]);
  if (!Number(due)) return c.jsonOut({ ok: true, due: 0 });
  const poll = await pollDue(25000);
  await runMaintenance(3600).catch(() => {});
  c.jsonOut({ ok: true, due: Number(due), results: poll.results.length });
});
