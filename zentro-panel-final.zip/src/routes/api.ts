import { GET, POST, route, Ctx, Handler } from '../http';
import { db, tx, isUniqueViolation, likeEscape } from '../db';
import { hashPassword } from '../auth';
import { USER_SQL, UserView, logActivity, roleByName } from '../models';
import { config } from '../config';
import { digitsOnly, errMsg, UserError } from '../util';
import { safeEqual } from '../http';
import { sharedRangeLimits, requestNumbers } from '../services/numbers';
import { ensureTestPool } from '../services/lifecycle';
import { addNumbersToRange, extractNumbers } from './ranges';

const fail = (c: Ctx, status: number, error: string) => { c.jsonOut({ error }, status); return false; };

/** X-API-Token authentication (header, or ?api_token=). Sets c.apiUser. */
const apiAuth: Handler = async (c) => {
  const token = (c.req.headers['x-api-token'] as string) || c.query.str('api_token');
  if (!token) return fail(c, 401, 'API token required');
  const row = await db.one(`${USER_SQL} where u.api_token = $1`, [token]);
  if (!row) return fail(c, 401, 'Invalid API token');
  const u = new UserView(row);
  if (!u.is_active) return fail(c, 403, 'Account inactive');
  if (!u.api_enabled) return fail(c, 403, 'API access is not enabled for this account');
  (c as any).apiUser = u;
};
const me = (c: Ctx): UserView => (c as any).apiUser;
const iso = (d: any) => (d?.isoformat ? d.isoformat() : d ?? null);
const pagination = (page: number, per: number, total: number) => ({ page, per_page: per, total, pages: Math.ceil(total / per), has_next: page * per < total, has_prev: page > 1 });
const pp = (c: Ctx, max: number) => {
  const per = Math.min(Math.max(c.query.int('per_page', 50)!, 1), max);
  const page = Math.max(c.query.int('page', 1)!, 1);
  return { page, per, offset: (page - 1) * per };
};

const rangeDict = (r: any) => ({ id: r.id, name: r.name, prefix: r.prefix, country: r.country, operator: r.operator, payout: r.payout, daily_limit: r.daily_limit, is_active: r.is_active });
const numberDict = (n: any) => ({ id: n.id, number: n.number, range_id: n.range_id, status: n.status, agent_id: n.agent_id, client_id: n.client_id, agent_payout: n.agent_payout, client_payout: n.client_payout, assigned_at: iso(n.assigned_at) });
const cdrDict = (r: any) => ({ id: r.id, number_id: r.number_id, range_id: r.range_id, destination: r.destination, cli: r.cli, caller_id: r.caller_id, message: r.message, sms_type: r.sms_type, status: r.status, agent_payout: r.agent_payout, client_payout: r.client_payout, profit: r.profit, currency: r.currency, created_at: iso(r.created_at) });
const userDict = (u: UserView) => u.to_dict();

// ── ranges ──
GET('api.ranges', '/api/sms/ranges', apiAuth, async (c) => {
  const { page, per, offset } = pp(c, 500);
  const s = c.query.str('search');
  const where = s ? `where is_active and (prefix ilike $1 or country ilike $1 or name ilike $1)` : `where is_active`;
  const p = s ? [`%${likeEscape(s)}%`] : [];
  const total = Number(await db.scalar(`select count(*) from sms_ranges ${where}`, p));
  const rows = await db.query(`select * from sms_ranges ${where} order by country, prefix limit ${per} offset ${offset}`, p);
  c.jsonOut({ results: rows.map(rangeDict), pagination: pagination(page, per, total) });
});
GET('api.range', '/api/sms/ranges/<int:range_id>', apiAuth, async (c) => {
  const r = await db.one(`select * from sms_ranges where id = $1`, [c.params.range_id]);
  if (!r) return void fail(c, 404, 'Range not found');
  c.jsonOut(rangeDict(r));
});

// ── numbers ──
GET('api.numbers', '/api/sms/numbers', apiAuth, async (c) => {
  const u = me(c);
  const { page, per, offset } = pp(c, 1000);
  const col = u.is_client() ? 'client_id' : 'agent_id';
  const params: any[] = [u.id];
  let where = `${col} = $1`;
  const rid = c.query.int('range_id');
  if (rid) { params.push(rid); where += ` and range_id = $${params.length}`; }
  const cid = c.query.int('client_id');
  if (cid && !u.is_client()) { params.push(cid); where += ` and client_id = $${params.length}`; }
  const total = Number(await db.scalar(`select count(*) from sms_numbers where ${where}`, params));
  const rows = await db.query(`select * from sms_numbers where ${where} order by number limit ${per} offset ${offset}`, params);
  c.jsonOut({ results: rows.map(numberDict), pagination: pagination(page, per, total) });
});

/** Your self-service limits per range. */
GET('api.limits', '/api/sms/limits', apiAuth, async (c) => {
  const rows = await sharedRangeLimits(db);
  c.jsonOut({ results: rows.map((r) => ({ range_id: r.id, prefix: r.prefix, country: r.country, limit: Number(r.total_limit), taken: Number(r.taken_count), remaining: Number(r.remaining), available_in_range: Number(r.available) })) });
});

/** Takes random numbers from a range, within the per-range limit set by the administrator. */
POST('api.request_numbers', '/api/sms/numbers/request', apiAuth, async (c) => {
  const u = me(c);
  if (!u.is_agent() && !u.is_client()) return void fail(c, 403, 'Only agents and clients can request numbers');
  const d = c.json || {};
  const rangeId = Number(d.range_id), qty = Number(d.quantity ?? 1);
  if (!Number.isInteger(rangeId) || !Number.isInteger(qty) || qty < 1 || qty > 10000) return void fail(c, 400, 'range_id and a quantity between 1 and 10000 are required');
  try {
    const res = await requestNumbers({ id: u.id, role: u.is_client() ? 'client' : 'agent' }, rangeId, qty);
    await logActivity(u.id, 'api_request_numbers', `Took ${res.got.length} numbers from range ${res.range.prefix}`, c.ip);
    c.jsonOut({ success: true, numbers: res.got.map((g: any) => g.number), count: res.got.length, requested: res.requested, remaining_limit: res.remaining, message: `${res.got.length} numbers added` });
  } catch (e) {
    if (e instanceof UserError) return void fail(c, 400, e.message);
    console.error('[api request_numbers]', e);
    fail(c, 500, 'Could not reserve numbers');
  }
});

// ── CDR ──
const cdrScope = (u: UserView) => (u.is_client() ? 'client_id' : 'user_id');
GET('api.cdr', '/api/sms/cdr', apiAuth, async (c) => {
  const u = me(c);
  const { page, per, offset } = pp(c, 500);
  const params: any[] = [u.id];
  let where = `${cdrScope(u)} = $1`;
  const add = (sql: string, v: any) => { params.push(v); where += ` and ${sql.replace('?', '$' + params.length)}`; };
  const rid = c.query.int('range_id'); if (rid) add('range_id = ?', rid);
  const cid = c.query.int('client_id'); if (cid && !u.is_client()) add('client_id = ?', cid);
  const t = c.query.str('type'); if (t) add('sms_type = ?', t);
  for (const [k, op] of [['date_from', '>='], ['date_to', '<=']] as const) {
    const v = c.query.str(k);
    if (v && !isNaN(Date.parse(v))) add(`created_at ${op} ?`, new Date(v));
  }
  const total = Number(await db.scalar(`select count(*) from sms_cdr where ${where}`, params));
  const rows = await db.query(`select * from sms_cdr where ${where} order by created_at desc, id desc limit ${per} offset ${offset}`, params);
  const hide = u.username === 'test';
  c.jsonOut({ results: rows.map((r) => ({ ...cdrDict(r), ...(hide ? { message: '[MESSAGE CONTENT HIDDEN IN TEST ACCOUNT]' } : {}) })), pagination: pagination(page, per, total) });
});

GET('api.cdr_stats', '/api/sms/cdr/stats', apiAuth, async (c) => {
  const u = me(c);
  const col = cdrScope(u);
  const s = await db.one(
    `select count(*) filter (where created_at >= date_trunc('day', timezone('utc', now()))) today,
            count(*) filter (where created_at >= now() - interval '7 days') week,
            count(*) filter (where created_at >= now() - interval '30 days') month,
            count(*) total,
            count(*) filter (where sms_type = 'received' and created_at >= date_trunc('day', timezone('utc', now()))) received_today,
            coalesce(sum(profit),0) revenue_total,
            coalesce(sum(profit) filter (where currency = 'USD'),0) usd
     from sms_cdr where ${col} = $1`, [u.id]);
  c.jsonOut({ today: s!.today, week: s!.week, month: s!.month, total: s!.total, received_today: s!.received_today, revenue: { total: Number(s!.revenue_total), USD: Number(s!.usd) } });
});

// ── clients (agents) ──
const needAgent: Handler = (c) => { const u = me(c); if (!u.is_agent() && !u.is_admin()) return fail(c, 403, 'Agent access required'); };
const myClient = (c: Ctx) => db.one(`${USER_SQL} where u.id = $1 and u.agent_id = $2`, [c.params.client_id, me(c).id]);

GET('api.clients', '/api/clients', apiAuth, needAgent, async (c) => {
  const { page, per, offset } = pp(c, 500);
  const params: any[] = [me(c).id];
  let where = 'u.agent_id = $1';
  const s = c.query.str('search');
  if (s) { params.push(`%${likeEscape(s)}%`); where += ` and (u.username ilike $2 or u.email ilike $2 or u.name ilike $2)`; }
  const total = Number(await db.scalar(`select count(*) from users u where ${where}`, params));
  const rows = await db.query(`${USER_SQL} where ${where} order by u.created_at desc limit ${per} offset ${offset}`, params);
  c.jsonOut({ results: rows.map((r) => userDict(new UserView(r))), pagination: pagination(page, per, total) });
});

POST('api.create_client', '/api/clients', apiAuth, needAgent, async (c) => {
  const d = c.json || {};
  const username = String(d.username || '').trim(), password = String(d.password || '');
  if (!username || password.length < 6) return void fail(c, 400, 'username and a password of at least 6 characters are required');
  const email = String(d.email || `${username}@client.local`).trim().toLowerCase();
  const role = await roleByName('client');
  try {
    const row = await db.one(
      `insert into users (username,email,role_id,agent_id,name,company,country,skype,is_active,password_hash) values ($1,$2,$3,$4,$5,$6,$7,$8,true,$9) returning id`,
      [username, email, role!.id, me(c).id, d.name ?? null, d.company ?? null, d.country ?? null, d.skype ?? null, await hashPassword(password)],
    );
    await logActivity(me(c).id, 'create_client', `Created client ${username}`, c.ip);
    const u = await db.one(`${USER_SQL} where u.id = $1`, [row!.id]);
    c.jsonOut({ success: true, client: userDict(new UserView(u!)) }, 201);
  } catch (e) {
    if (isUniqueViolation(e)) return void fail(c, 400, 'Username or email already exists');
    throw e;
  }
});
GET('api.client', '/api/clients/<int:client_id>', apiAuth, needAgent, async (c) => {
  const r = await myClient(c);
  if (!r) return void fail(c, 404, 'Client not found');
  c.jsonOut(userDict(new UserView(r)));
});
route('PUT', 'api.update_client', '/api/clients/<int:client_id>', apiAuth, needAgent, async (c) => {
  const r = await myClient(c);
  if (!r) return void fail(c, 404, 'Client not found');
  const d = c.json || {};
  const set: string[] = [], p: any[] = [r.id];
  for (const f of ['name', 'company', 'country', 'skype', 'contact', 'address']) if (f in d) { p.push(d[f] == null ? null : String(d[f])); set.push(`${f} = $${p.length}`); }
  if ('email' in d) { p.push(String(d.email).trim().toLowerCase()); set.push(`email = $${p.length}`); }
  if ('is_active' in d) { p.push(!!d.is_active); set.push(`is_active = $${p.length}`); }
  if (d.password) { if (String(d.password).length < 6) return void fail(c, 400, 'password too short'); p.push(await hashPassword(String(d.password))); set.push(`password_hash = $${p.length}`); }
  try {
    if (set.length) await db.exec(`update users set ${set.join(', ')} where id = $1`, p);
  } catch (e) {
    if (isUniqueViolation(e)) return void fail(c, 400, 'Email already registered');
    throw e;
  }
  await logActivity(me(c).id, 'update_client', `Updated client ${r.username}`, c.ip);
  c.jsonOut({ success: true, client: userDict(new UserView((await db.one(`${USER_SQL} where u.id = $1`, [r.id]))!)) });
});
route('DELETE', 'api.delete_client', '/api/clients/<int:client_id>', apiAuth, needAgent, async (c) => {
  const r = await myClient(c);
  if (!r) return void fail(c, 404, 'Client not found');
  if (Number(await db.scalar(`select count(*) from sms_numbers where client_id = $1`, [r.id])) > 0) return void fail(c, 400, 'Cannot delete client with assigned numbers');
  await db.exec(`delete from users where id = $1`, [r.id]);
  await logActivity(me(c).id, 'delete_client', `Deleted client ${r.username}`, c.ip);
  c.jsonOut({ success: true, message: `Client ${r.username} deleted` });
});

// ── allocation of own numbers to clients ──
async function setClient(agentId: number, numberIds: number[], clientId: number | null, payout?: number) {
  if (clientId) {
    return db.exec(
      `update sms_numbers set client_id = $1, status = 'activated', assigned_at = now(), client_payout = coalesce($4, client_payout)
       where id = any($2::int[]) and agent_id = $3 and (client_id is null or client_id = $1) and status not in ('test','test_pool')`,
      [clientId, numberIds, agentId, payout ?? null],
    );
  }
  return db.exec(`update sms_numbers set client_id = null, client_payout = 0, status = 'reserved' where id = any($1::int[]) and agent_id = $2 and status not in ('test','test_pool')`, [numberIds, agentId]);
}
const ownsClient = async (agentId: number, clientId: number) => !!(await db.one(`select 1 from users where id = $1 and agent_id = $2`, [clientId, agentId]));
const intList = (v: any) => (Array.isArray(v) ? v.map(Number).filter(Number.isInteger) : []);

POST('api.allocate', '/api/numbers/allocate', apiAuth, needAgent, async (c) => {
  const d = c.json || {};
  const nid = Number(d.number_id);
  if (!nid) return void fail(c, 400, 'number_id required');
  if (d.client_id && !(await ownsClient(me(c).id, Number(d.client_id)))) return void fail(c, 404, 'Client not found');
  const n = await setClient(me(c).id, [nid], d.client_id ? Number(d.client_id) : null, d.client_payout != null ? Number(d.client_payout) : undefined);
  if (!n) return void fail(c, 404, 'Number not found or already assigned to another client');
  c.jsonOut({ success: true, number: numberDict((await db.one(`select * from sms_numbers where id = $1`, [nid]))!) });
});
POST('api.unallocate', '/api/numbers/unallocate', apiAuth, needAgent, async (c) => {
  const nid = Number((c.json || {}).number_id);
  if (!nid) return void fail(c, 400, 'number_id required');
  if (!(await setClient(me(c).id, [nid], null))) return void fail(c, 404, 'Number not found');
  c.jsonOut({ success: true, number: numberDict((await db.one(`select * from sms_numbers where id = $1`, [nid]))!) });
});
POST('api.bulk_allocate', '/api/numbers/bulk-allocate', apiAuth, needAgent, async (c) => {
  const d = c.json || {};
  const ids = intList(d.number_ids);
  if (!ids.length) return void fail(c, 400, 'number_ids required');
  if (d.client_id && !(await ownsClient(me(c).id, Number(d.client_id)))) return void fail(c, 404, 'Client not found');
  const n = await setClient(me(c).id, ids, d.client_id ? Number(d.client_id) : null, d.client_payout != null ? Number(d.client_payout) : undefined);
  c.jsonOut({ success: true, updated: n });
});

// ── admin: CSV import ──
POST('api.import_csv', '/api/numbers/import-csv', apiAuth, async (c) => {
  if (!me(c).is_admin()) return void fail(c, 403, 'Admin access required for bulk import');
  const rangeId = c.form.int('range_id');
  const file = c.files['csv_file'];
  if (!rangeId) return void fail(c, 400, 'range_id is required');
  if (!file) return void fail(c, 400, 'csv_file is required');
  const range = await db.one(`select * from sms_ranges where id = $1`, [rangeId]);
  if (!range) return void fail(c, 404, 'Range not found');
  const nums = extractNumbers(file.data.toString('utf8'), '');
  const { created: added, skipped } = await tx(async (t) => {
    const r = await addNumbersToRange(t, range, nums);
    await ensureTestPool(t, range);
    return r;
  });
  await logActivity(me(c).id, 'bulk_import_csv', `Imported ${added} numbers to range ${range.prefix}`, c.ip);
  c.jsonOut({ success: true, imported: added, duplicates_skipped: skipped, errors: 0, message: `${added} numbers imported successfully` });
});

// ── receiving SMS ──
async function logReceived(numberRow: any, from: string, cli: string, message: string, paid: boolean) {
  const ap = paid ? Number(numberRow.agent_payout) || 0 : 0;
  const cp = paid ? Number(numberRow.client_payout) || 0 : 0;
  return db.one(
    `insert into sms_cdr (number_id, range_id, user_id, client_id, caller_id, cli, destination, message, sms_type, status, agent_payout, client_payout, profit, currency)
     values ($1,$2,$3,$4,$5,$6,$7,$8,'received','completed',$9,$10,$11,'USD') returning id`,
    [numberRow.id, numberRow.range_id, numberRow.agent_id, numberRow.client_id, from.slice(0, 255), cli.slice(0, 255), numberRow.number, message, ap, cp, cp - ap],
  );
}

/** Webhook for an SMS gateway. Requires SMS_WEBHOOK_SECRET (header X-Webhook-Secret); disabled when it is not set. */
POST('api.receive_sms', '/api/sms/receive', async (c) => {
  if (!config.webhookSecret) return void fail(c, 503, 'Webhook disabled: set SMS_WEBHOOK_SECRET on the server');
  const given = String(c.req.headers['x-webhook-secret'] || '');
  if (!given || !safeEqual(given, config.webhookSecret)) return void fail(c, 401, 'Invalid webhook secret');
  const d = c.json || {};
  const number = digitsOnly(String(d.number || '')), from = String(d.from || '');
  if (!number || !from) return void fail(c, 400, 'number and from are required');
  const n = await db.one(`select * from sms_numbers where number = $1`, [number]);
  if (!n) return void fail(c, 404, 'SMS number not found');
  if (!n.agent_id && !n.client_id) return void fail(c, 400, 'Number has no assigned owner');
  const message = String(d.message || '');
  const row = await logReceived(n, from, String(d.cli || from), message, true);
  c.jsonOut({ success: true, cdr_id: row!.id, message: 'SMS received and logged' });
});

/** Admin-only simulation for testing (never pays anyone). */
POST('api.sms_scr', '/api/sms/scr', apiAuth, async (c) => {
  if (!me(c).is_admin()) return void fail(c, 403, 'Admin access required');
  const d = c.json || {};
  const number = digitsOnly(String(d.number || ''));
  if (!number) return void fail(c, 400, 'number is required');
  const n = await db.one(`select * from sms_numbers where number = $1`, [number]);
  if (!n) return void fail(c, 404, 'SMS number not found');
  const row = await logReceived(n, String(d.from || 'SCR-TEST'), String(d.cli || 'Test'), String(d.message || 'Test SMS received'), false);
  c.jsonOut({ success: true, cdr_id: row!.id, message: 'Simulated SMS logged (no payout)' });
});

const notSupported: Handler = (c) => { c.jsonOut({ error: 'Sending SMS is not supported by this panel. This panel only receives SMS.' }, 410); };
POST('api.send_sms', '/api/sms/send', notSupported);
POST('api.send_sms_bulk', '/api/sms/send-bulk', notSupported);
void errMsg;
