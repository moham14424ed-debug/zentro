import { GET, ANY, POST, urlFor, Ctx } from '../http';
import { db } from '../db';
import { render } from '../views';
import { checkPassword, hashPassword, loginRequired, loginUser, logoutUser, newCaptcha, verifyCaptcha } from '../auth';
import { logActivity } from '../models';
import { config } from '../config';

const DUMMY_HASH = '$2b$12$C6UzMDM.H6dfI/f/IKcEeO5N3o8hGJ8aV7v1xZk5Y6o8T3m3kUo1S';
const safeNext = (n: string | null) => (n && n.startsWith('/') && !n.startsWith('//') && !n.startsWith('/\\') ? n : null);
const noStore = (c: Ctx) => {
  if (c.out) c.out.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0';
};

function renderLogin(c: Ctx, status = 200) {
  render(c, 'auth/login.html', { captcha: newCaptcha(), next_url: safeNext(c.query.get('next')) }, status);
  noStore(c);
}

GET('auth.index', '/', (c) => {
  c.redirect(c.user ? urlFor('main.dashboard') : urlFor('auth.login'));
});

ANY('auth.login', '/login', async (c) => {
  if (c.user) return c.redirect(urlFor('main.dashboard'));
  if (c.method !== 'POST') return renderLogin(c);

  const username = c.form.str('username');
  const password = c.form.get('password', '') as string;
  if (!username || !password) {
    c.flash('Please enter username and password.', 'danger');
    return renderLogin(c);
  }
  const okCaptcha = verifyCaptcha(
    Number(c.form.get('captcha_num1', 0)),
    Number(c.form.get('captcha_num2', 0)),
    Number(c.form.get('captcha_exp', 0)),
    c.form.get('captcha_sig', ''),
    c.form.get('capt', ''),
  );
  if (!okCaptcha) {
    c.flash('Incorrect captcha answer. Please try again.', 'danger');
    return renderLogin(c);
  }

  const user = await db.one(`select * from users where username = $1`, [username]);
  if (!user) {
    await checkPassword(password, DUMMY_HASH); // keep timing similar for unknown users
    c.flash('Invalid username or password.', 'danger');
    return renderLogin(c);
  }
  if (user.locked_until && user.locked_until > new Date()) {
    c.flash('Your account is locked. Please try again later.', 'danger');
    return renderLogin(c);
  }
  if (!(await checkPassword(password, user.password_hash))) {
    const attempts = (user.login_attempts || 0) + 1;
    if (attempts >= config.loginAttemptLimit) {
      await db.exec(`update users set login_attempts = $2, locked_until = now() + ($3 || ' minutes')::interval where id = $1`, [user.id, attempts, String(config.lockMinutes)]);
      c.flash(`Too many failed attempts. Account locked for ${config.lockMinutes} minutes.`, 'danger');
    } else {
      await db.exec(`update users set login_attempts = $2 where id = $1`, [user.id, attempts]);
      c.flash(`Invalid credentials. ${config.loginAttemptLimit - attempts} attempts remaining.`, 'danger');
    }
    return renderLogin(c);
  }
  if (!user.is_active) {
    c.flash('Your account has been deactivated.', 'warning');
    return renderLogin(c);
  }
  await db.exec(`update users set login_attempts = 0, locked_until = null, last_login = now() where id = $1`, [user.id]);
  await logActivity(user.id, 'login', 'User logged in', c.ip, c.userAgent);
  loginUser(c, user as any, user.password_hash);
  c.flash(`Welcome ${user.username}!`, 'success');
  c.redirect(safeNext(c.query.get('next')) || urlFor('main.dashboard'));
});

GET('auth.logout', '/logout', loginRequired, async (c) => {
  await logActivity(c.user.id, 'logout', 'User logged out', c.ip);
  logoutUser(c);
  c.flash('You have been logged out.', 'info');
  c.redirect(urlFor('auth.login'));
});

// ── password reset (username → registered e-mail → new password) ──
// Only roles listed in SELF_RESET_ROLES (default: client) may use it, because anybody who knows
// a username and its e-mail could otherwise take over an agent's wallet or the admin account.
const selfResetRoles = (process.env.SELF_RESET_ROLES || 'client').split(',').map((s) => s.trim());

ANY('auth.reset_password', '/reset-password', async (c) => {
  const now = Date.now() / 1000;
  let reset = c.session.reset;
  if (reset && now - reset.started > 900) {
    c.setSession({ reset: undefined });
    reset = undefined;
  }
  const step = !reset ? 'username' : reset.verified ? 'password' : 'email';

  if (c.method === 'POST') {
    if (step === 'username') {
      const username = c.form.str('username');
      if (!username) c.flash('Please enter your username.', 'danger');
      else {
        const u = await db.one(`select u.username, r.name as role from users u left join roles r on r.id = u.role_id where u.username = $1`, [username]);
        if (!u) c.flash('We could not verify those details. Please check your username and try again.', 'danger');
        else if (!selfResetRoles.includes(u.role)) c.flash('Password reset for this account type must be done by the administrator. Please contact support.', 'warning');
        else {
          c.setSession({ reset: { username: u.username, started: now } });
          c.flash('Username accepted. To confirm your identity, enter the email address for this account.', 'info');
          return c.redirect(urlFor('auth.reset_password'));
        }
      }
    } else if (step === 'email') {
      const email = c.form.str('email').toLowerCase();
      const u = await db.one(`select email from users where username = $1`, [reset!.username]);
      if (!u || !email || email !== String(u.email || '').trim().toLowerCase()) {
        c.setSession({ reset: undefined });
        c.flash('We could not verify those details. Please start again.', 'danger');
      } else {
        c.setSession({ reset: { ...reset!, verified: true } });
        c.flash('Identity confirmed. Set your new password below.', 'info');
        return c.redirect(urlFor('auth.reset_password'));
      }
    } else {
      const pw = c.form.get('password', '') as string;
      const pw2 = c.form.get('password_confirm', '') as string;
      if (pw.length < 6) c.flash('The new password must be at least 6 characters.', 'danger');
      else if (pw !== pw2) c.flash('The passwords do not match.', 'danger');
      else {
        const u = await db.one(`select id from users where username = $1`, [reset!.username]);
        if (!u) {
          c.setSession({ reset: undefined });
          c.flash('We could not complete the password reset. Please start again.', 'danger');
        } else {
          await db.exec(`update users set password_hash = $2, login_attempts = 0, locked_until = null where id = $1`, [u.id, await hashPassword(pw)]);
          await logActivity(u.id, 'password_reset', 'Password reset after username and email verification', c.ip);
          c.setSession({ reset: undefined });
          c.flash('Your password has been changed successfully. You can now log in.', 'success');
          return c.redirect(urlFor('auth.login'));
        }
      }
    }
    return c.redirect(urlFor('auth.reset_password'));
  }
  render(c, 'auth/reset_password.html', { step, reset_username: reset?.username });
});

ANY('auth.register', '/register', async (c) => {
  if (c.user) return c.redirect(urlFor('main.dashboard'));
  if (process.env.ALLOW_REGISTRATION === 'false') {
    c.flash('Registration is closed. Please contact the administrator.', 'warning');
    return c.redirect(urlFor('auth.login'));
  }
  if (c.method !== 'POST') return render(c, 'auth/register.html');

  const username = c.form.str('username');
  const email = c.form.str('email');
  const password = c.form.get('password', '') as string;
  const confirm = c.form.get('password_confirm', '') as string;
  const errors: string[] = [];
  if (username.length < 6) errors.push('Username must be at least 6 characters.');
  if (!/^[A-Za-z0-9_]+$/.test(username)) errors.push('Username can only contain letters, numbers, and underscores.');
  if (!/^[\w.-]+@[\w.-]+\.\w+$/.test(email)) errors.push('Please enter a valid email address.');
  if (password.length < 6) errors.push('Password must be at least 6 characters.');
  if (password !== confirm) errors.push('Passwords do not match.');
  if (await db.scalar(`select 1 from users where lower(username) = lower($1)`, [username])) errors.push('Username already exists.');
  if (await db.scalar(`select 1 from users where lower(email) = lower($1)`, [email])) errors.push('Email already registered.');
  if (errors.length) {
    errors.forEach((e) => c.flash(e, 'danger'));
    return render(c, 'auth/register.html');
  }
  const role = await db.one(`select id from roles where name = 'client'`);
  const row = await db.one(`insert into users (username, email, password_hash, role_id, is_active) values ($1,$2,$3,$4,true) returning id`, [username, email, await hashPassword(password), role?.id ?? null]);
  await logActivity(row!.id, 'register', 'New user registered', c.ip);
  c.flash('Registration successful! Please log in.', 'success');
  c.redirect(urlFor('auth.login'));
});
