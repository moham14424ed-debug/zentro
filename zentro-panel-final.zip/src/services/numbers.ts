import { Queryable, Row, tx } from '../db';
import { UserError, startOfUtcDay } from '../util';
import { ensureTestPool } from './lifecycle';

export type OwnerRole = 'agent' | 'client';

/**
 * Atomically assigns up to `count` free numbers of a range to a user.
 * Rows are locked with FOR UPDATE SKIP LOCKED, so two people can never get the same number.
 */
export async function allocateFromRange(
  t: Queryable,
  opts: { range: Row; role: OwnerRole; ownerId: number; count: number; random?: boolean },
): Promise<Row[]> {
  const { range, role, ownerId, count, random } = opts;
  if (count < 1) return [];
  await ensureTestPool(t, range); // keep the 10 quality-test numbers out of the sellable pool
  const ownerCol = role === 'agent' ? 'agent_id' : 'client_id';
  const status = role === 'agent' ? 'reserved' : 'activated';
  const payoutCol = role === 'agent' ? 'agent_payout' : 'client_payout';
  return t.query(
    `update sms_numbers set ${ownerCol} = $2, status = $3, assigned_at = now(), ${payoutCol} = $4
     where id in (
       select id from sms_numbers
       where range_id = $1 and agent_id is null and client_id is null and is_active
         and status in ('available','reserved')
       order by ${random ? 'random()' : 'id'}
       limit $5 for update skip locked)
     returning id, number`,
    [range.id, ownerId, status, Number(range.payout) || 0, count],
  );
}

export interface QuotaInfo {
  range_id: number;
  total_limit: number;
  taken_count: number;
  daily_limit: number;
  remaining: number;
}

/**
 * Self-service allocation uses one shared cap per Range. The Range row is locked first so
 * concurrent users consume the same global budget safely; selected numbers are random.
 */
export async function requestNumbers(user: { id: number; role: OwnerRole }, rangeId: number, wanted: number) {
  if (!Number.isInteger(wanted) || wanted < 1) throw new UserError('Enter a valid quantity.');
  return tx(async (t) => {
    const range = await t.one(`select * from sms_ranges where id = $1 and is_active for update`, [rangeId]);
    if (!range) throw new UserError('This range is not available.');
    const taken = Number(await t.scalar(
      `select count(*) from sms_numbers where range_id = $1 and (agent_id is not null or client_id is not null) and status <> 'test'`,
      [rangeId],
    ));
    const cap = Number(range.self_service_limit) || 0;
    const sharedRemaining = cap > 0 ? Math.max(cap - taken, 0) : Number.MAX_SAFE_INTEGER;
    if (cap > 0 && sharedRemaining <= 0) throw new UserError(`The shared limit for this range has been reached (${cap} numbers).`);
    const available = Number(await t.scalar(
      `select count(*) from sms_numbers where range_id = $1 and agent_id is null and client_id is null and is_active and status in ('available','reserved')`,
      [rangeId],
    ));
    if (!available) throw new UserError('No free numbers are available in this range right now.');
    const take = Math.min(wanted, sharedRemaining, available);
    const got = await allocateFromRange(t, { range, role: user.role, ownerId: user.id, count: take, random: true });
    if (!got.length) throw new UserError('No free numbers are available in this range right now.');
    const remaining = cap > 0 ? Math.max(cap - taken - got.length, 0) : 0;
    return { range, got, requested: wanted, clamped: take < wanted, remaining, shared: true, cap, taken: taken + got.length };
  });
}

/** Shared cap and live stock for a set of Ranges. `remaining = -1` means unlimited. */
export async function sharedRangeLimits(q: Queryable, rangeIds?: number[]): Promise<Row[]> {
  const params: any[] = [];
  let filter = '';
  if (rangeIds?.length) { params.push(rangeIds); filter = 'and r.id = any($1::int[])'; }
  return q.query(
    `select r.id, r.name, r.prefix, r.country, r.operator, r.payout, r.is_active,
            coalesce(r.self_service_limit, 0) as total_limit,
            count(n.id) filter (where n.agent_id is not null or n.client_id is not null) as taken_count,
            case when coalesce(r.self_service_limit, 0) = 0 then -1
                 else greatest(coalesce(r.self_service_limit, 0) - count(n.id) filter (where n.agent_id is not null or n.client_id is not null), 0) end as remaining,
            count(n.id) filter (where n.agent_id is null and n.client_id is null and n.is_active and n.status in ('available','reserved')) as available
     from sms_ranges r left join sms_numbers n on n.range_id = r.id
     where r.is_active ${filter}
     group by r.id order by r.country, r.prefix`,
    params,
  );
}

/** Limits of one user across ranges (for the user page and the admin editor). */
export async function limitsForUser(q: Queryable, userId: number): Promise<Row[]> {
  return q.query(
    `select r.id, r.name, r.prefix, r.country, r.operator, r.payout, r.is_active,
            coalesce(l.total_limit, 0) as total_limit, coalesce(l.taken_count, 0) as taken_count,
            coalesce(l.daily_limit, 0) as daily_limit,
            greatest(coalesce(l.total_limit, 0) - coalesce(l.taken_count, 0), 0) as remaining,
            (select count(*) from sms_numbers n where n.range_id = r.id and n.agent_id is null and n.client_id is null
               and n.is_active and n.status in ('available','reserved')) as available
     from sms_ranges r
     left join agent_range_limits l on l.range_id = r.id and l.agent_id = $1
     where r.is_active
     order by r.country, r.prefix`,
    [userId],
  );
}

export async function setLimit(q: Queryable, userId: number, rangeId: number, total: number, daily = 0, resetTaken = false) {
  await q.exec(
    `insert into agent_range_limits (agent_id, range_id, total_limit, daily_limit, taken_count)
     values ($1,$2,$3,$4,0)
     on conflict (agent_id, range_id) do update
       set total_limit = excluded.total_limit, daily_limit = excluded.daily_limit,
           taken_count = case when $5::boolean then 0 else agent_range_limits.taken_count end`,
    [userId, rangeId, Math.max(0, total), Math.max(0, daily), resetTaken],
  );
}
