/** Periodic maintenance, run by the cron endpoint / ticker (serverless has no background threads). */
import { config } from '../config';
import { db } from '../db';
import { errMsg } from '../util';
import { logActivity } from '../models';
import { resetNumbersToPool } from './lifecycle';

/** Weekly credit note per agent covering 7 days of earnings; catches up one week per run. */
export async function generateWeeklyCreditNotes(): Promise<number> {
  const agents = await db.query(`select u.id, u.created_at from users u join roles r on r.id = u.role_id where r.name = 'agent'`);
  let made = 0;
  const now = new Date();
  for (const a of agents) {
    const last = await db.one(`select period_end from credit_notes where agent_id = $1 order by period_end desc limit 1`, [a.id]);
    const start: Date = last ? last.period_end : a.created_at;
    if (now.getTime() - start.getTime() < 7 * 86400000) continue;
    const end = new Date(start.getTime() + 7 * 86400000);
    const total = Number(await db.scalar(`select coalesce(sum(agent_payout),0) from sms_cdr where user_id = $1 and created_at >= $2 and created_at < $3`, [a.id, start, end])) || 0;
    await db.exec(
      `insert into credit_notes (agent_id, period_start, period_end, amount, currency, issued_at, due_date, status) values ($1,$2,$3,$4,'USDT',$5,$6,'pending')`,
      [a.id, start, end, Math.round(total * 10000) / 10000, now, new Date(now.getTime() + 7 * 86400000)],
    );
    made++;
  }
  return made;
}

/** Optional: take back numbers that received too little traffic after the grace period. */
export async function autoReturnLowTraffic(): Promise<number> {
  if (!config.autoReturnEnabled) return 0;
  const cutoff = new Date(Date.now() - config.autoReturnAfterHours * 3600000);
  const rows = await db.query(
    `select n.id, n.number, n.agent_id from sms_numbers n
     where n.agent_id is not null and n.assigned_at is not null and n.assigned_at <= $1 and n.status in ('reserved','activated')
       and (select count(*) from sms_cdr c where c.number_id = n.id and c.sms_type = 'received' and c.created_at >= n.assigned_at) < $2
     limit 2000`,
    [cutoff, config.autoReturnMinSms],
  );
  if (!rows.length) return 0;
  await resetNumbersToPool(db, rows.map((r) => r.id));
  for (const r of rows.slice(0, 50)) await logActivity(r.agent_id, 'auto_return_low_traffic', `Number ${r.number} returned automatically (low traffic)`);
  return rows.length;
}

/** Runs the maintenance jobs at most once per `everySeconds` across all instances. */
export async function runMaintenance(everySeconds = 3600, force = false) {
  const claimed = await db.one(
    `insert into app_meta (key, value) values ('maintenance_last', now()::text)
     on conflict (key) do update set value = now()::text, updated_at = now()
       where $2::boolean or app_meta.updated_at < now() - make_interval(secs => $1::int)
     returning key`,
    [everySeconds, force],
  );
  if (!claimed) return { ran: false };
  const out: Record<string, any> = { ran: true };
  try { out.credit_notes = await generateWeeklyCreditNotes(); } catch (e) { out.credit_notes_error = errMsg(e); }
  try { out.auto_returned = await autoReturnLowTraffic(); } catch (e) { out.auto_return_error = errMsg(e); }
  return out;
}
