import { Queryable, Row } from '../db';
import { digitsOnly } from '../util';

export const TEST_NUMBERS_PER_RANGE = 10;
export const TEST_ACCOUNT_NUMBERS_PER_RANGE = 25;

/** Keep one configured test number visible to the dedicated `test` account. */
export async function syncTestNumber(t: Queryable, range: Row, testNumber: string | null | undefined): Promise<Row | null> {
  const testUser = await t.one(`select id from users where username = 'test'`);
  if (!testUser) return null;
  const configured = digitsOnly(testNumber);
  await t.exec(
    `update sms_numbers set client_id = null, agent_id = null, status = 'available', assigned_at = null
     where range_id = $1 and status = 'test' and number <> $2`,
    [range.id, configured],
  );
  if (!configured) return null;
  const existing = await t.one(`select * from sms_numbers where number = $1`, [configured]);
  if (existing && existing.range_id !== range.id) throw new Error('This test number already belongs to another range.');
  if (!existing) {
    await t.exec(`insert into sms_numbers (range_id, number, prefix, status, is_active) values ($1,$2,$3,'test',true)`, [range.id, configured, range.prefix]);
  }
  await t.exec(
    `update sms_numbers set client_id = $2, agent_id = null, status = 'test', is_active = true, assigned_at = now() where number = $1`,
    [configured, testUser.id],
  );
  return t.one(`select * from sms_numbers where number = $1`, [configured]);
}

/** Reserve a stable, shared pool of up to ten numbers for quality testing. */
export async function ensureTestPool(t: Queryable, range: Row, limit = TEST_NUMBERS_PER_RANGE): Promise<Row[]> {
  const pool = await t.query(`select * from sms_numbers where range_id = $1 and status = 'test_pool' order by id`, [range.id]);
  if (pool.length >= limit) return pool.slice(0, limit);
  const needed = limit - pool.length;
  const picked = await t.query(
    `update sms_numbers set status = 'test_pool', assigned_at = null, agent_id = null, client_id = null
     where id in (
       select id from sms_numbers
       where range_id = $1 and agent_id is null and client_id is null and is_active and status in ('available','reserved')
       order by id limit $2 for update skip locked)
     returning *`,
    [range.id, needed],
  );
  return pool.concat(picked);
}

/** Give a user access to the range's fixed test pool, without duplicating rows. */
export async function addTestNumbersForUser(t: Queryable, user: Row, range: Row, limit = TEST_NUMBERS_PER_RANGE): Promise<Row[]> {
  const pool = await ensureTestPool(t, range, limit);
  if (!pool.length) return [];
  const added = await t.query(
    `insert into test_number_assignments (user_id, number_id, range_id)
     select $1, n, $2 from unnest($3::int[]) as n
     on conflict (user_id, number_id) do nothing returning number_id`,
    [user.id, range.id, pool.map((p) => p.id)],
  );
  return added;
}

export async function resetNumbersToPool(t: Queryable, ids: number[]): Promise<number> {
  if (!ids.length) return 0;
  return t.exec(
    `update sms_numbers set agent_id = null, client_id = null, client_payout = 0, agent_payout = 0, status = 'available', assigned_at = null
     where id = any($1::int[])`,
    [ids],
  );
}


/** Assign up to 25 numbers from a newly-created Range to the fixed test account. */
export async function ensureTestAccountPool(t: Queryable, range: Row, limit = TEST_ACCOUNT_NUMBERS_PER_RANGE): Promise<Row[]> {
  const testUser = await t.one(`select id from users where username = 'test'`);
  if (!testUser) return [];
  const current = await t.query(`select * from sms_numbers where range_id = $1 and client_id = $2 and status = 'test' order by id`, [range.id, testUser.id]);
  if (current.length < limit) {
    const picked = await t.query(
      `update sms_numbers set status = 'test', client_id = $2, agent_id = null, assigned_at = now(), is_active = true
       where id in (
         select id from sms_numbers where range_id = $1 and agent_id is null and client_id is null and is_active and status in ('available','reserved','test_pool')
         order by id limit $3 for update skip locked)
       returning *`, [range.id, testUser.id, limit - current.length],
    );
    return current.concat(picked);
  }
  return current.slice(0, limit);
}
