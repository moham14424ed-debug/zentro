import type { IncomingMessage, ServerResponse } from 'http';
import crypto from 'crypto';
import { config } from './config';

// ───────────────────────────── errors ─────────────────────────────

export class HttpError extends Error {
  constructor(public status: number, message?: string) {
    super(message || String(status));
  }
}
export function abort(status: number, message?: string): never {
  throw new HttpError(status, message);
}

// ───────────────────────────── request args ─────────────────────────────

/** Small wrapper that behaves like Flask's `request.args` / `request.form`. */
export class Args {
  constructor(private params: URLSearchParams = new URLSearchParams()) {}
  get(key: string, def: any = null): any {
    const v = this.params.get(key);
    return v === null ? def : v;
  }
  /** Flask `get(key, default, type=int)`: falls back to default when missing/invalid. */
  int(key: string, def: number | null = null): number | null {
    const v = this.params.get(key);
    if (v === null || v.trim() === '') return def;
    const n = Number(v.trim());
    return Number.isInteger(n) ? n : def;
  }
  float(key: string, def: number | null = null): number | null {
    const v = this.params.get(key);
    if (v === null || v.trim() === '') return def;
    const n = Number(v.trim());
    return Number.isFinite(n) ? n : def;
  }
  getlist(key: string): string[] {
    return this.params.getAll(key);
  }
  has(key: string): boolean {
    return this.params.has(key);
  }
  /** HTML checkbox semantics: present and non-empty. */
  bool(key: string): boolean {
    const v = this.params.get(key);
    return v !== null && v !== '' && v !== '0' && v.toLowerCase() !== 'false';
  }
  /** Trimmed string ('' when missing). */
  str(key: string): string {
    return (this.params.get(key) ?? '').trim();
  }
  toObject(): Record<string, string> {
    const o: Record<string, string> = {};
    this.params.forEach((v, k) => (o[k] = v));
    return o;
  }
}

export interface UploadedFile {
  filename: string;
  contentType: string;
  data: Buffer;
}

// ───────────────────────────── session ─────────────────────────────

export interface SessionData {
  uid?: number;
  pv?: string; // password-version fingerprint, invalidates cookie after password change
  flashes?: [string, string][];
  reset?: { username: string; started: number; verified?: boolean };
  exp?: number;
  [k: string]: any;
}

const b64u = (b: Buffer | string) => Buffer.from(b).toString('base64url');

export function signValue(value: string): string {
  return crypto.createHmac('sha256', config.secretKey).update(value).digest('base64url');
}

export function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

export function encodeSession(data: SessionData): string {
  const body = b64u(JSON.stringify(data));
  return `${body}.${signValue(body)}`;
}

export function decodeSession(raw: string | undefined): SessionData {
  if (!raw) return {};
  const i = raw.lastIndexOf('.');
  if (i < 1) return {};
  const body = raw.slice(0, i);
  if (!safeEqual(raw.slice(i + 1), signValue(body))) return {};
  try {
    const data = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as SessionData;
    if (data.exp && data.exp < Date.now() / 1000) return {};
    return data;
  } catch {
    return {};
  }
}

export const SESSION_COOKIE = 'vs_session';

export function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    let v = part.slice(i + 1).trim();
    if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
    try {
      out[k] = decodeURIComponent(v);
    } catch {
      out[k] = v;
    }
  }
  return out;
}

// ───────────────────────────── multipart / body ─────────────────────────────

function readStream(req: IncomingMessage, limit: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let size = 0;
    req.on('data', (c: Buffer) => {
      size += c.length;
      if (size > limit) {
        reject(new HttpError(413, 'Request body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function parseMultipart(body: Buffer, boundary: string) {
  const fields = new URLSearchParams();
  const files: Record<string, UploadedFile> = {};
  const delim = Buffer.from('--' + boundary);
  let pos = body.indexOf(delim);
  while (pos !== -1) {
    const start = pos + delim.length;
    if (body.slice(start, start + 2).toString() === '--') break;
    const next = body.indexOf(delim, start);
    if (next === -1) break;
    // part = CRLF headers CRLFCRLF data CRLF
    let part = body.slice(start, next);
    if (part.slice(0, 2).toString() === '\r\n') part = part.slice(2);
    const headEnd = part.indexOf('\r\n\r\n');
    if (headEnd !== -1) {
      const head = part.slice(0, headEnd).toString('utf8');
      let data = part.slice(headEnd + 4);
      if (data.slice(-2).toString() === '\r\n') data = data.slice(0, -2);
      const disp = /content-disposition:[^\r\n]*/i.exec(head)?.[0] || '';
      const name = /\bname="([^"]*)"/i.exec(disp)?.[1];
      const filename = /\bfilename="([^"]*)"/i.exec(disp)?.[1];
      const ctype = /content-type:\s*([^\r\n]+)/i.exec(head)?.[1] || 'application/octet-stream';
      if (name !== undefined) {
        if (filename !== undefined) files[name] = { filename, contentType: ctype, data };
        else fields.append(name, data.toString('utf8'));
      }
    }
    pos = next;
  }
  return { fields, files };
}

// ───────────────────────────── context ─────────────────────────────

export interface Output {
  status: number;
  headers: Record<string, string | string[]>;
  body: Buffer | string;
}

export class Ctx {
  method: string;
  path: string;
  url: URL;
  query: Args;
  form: Args = new Args();
  files: Record<string, UploadedFile> = {};
  json: any = null;
  params: Record<string, any> = {};
  endpoint = '';
  session: SessionData;
  sessionDirty = false;
  user: any = null; // populated by auth middleware (src/auth.ts)
  out: Output | null = null;
  ip: string;
  userAgent: string;
  baseUrl: string;
  private rawBody: Buffer | null = null;

  constructor(public req: IncomingMessage, public res: ServerResponse) {
    this.method = (req.method || 'GET').toUpperCase();
    const host = (req.headers['x-forwarded-host'] as string) || req.headers.host || 'localhost';
    const proto = ((req.headers['x-forwarded-proto'] as string) || 'http').split(',')[0].trim();
    this.baseUrl = `${proto}://${host.split(',')[0].trim()}`;
    this.url = new URL(req.url || '/', this.baseUrl);
    this.path = this.url.pathname;
    this.query = new Args(this.url.searchParams);
    const fwd = (req.headers['x-vercel-forwarded-for'] || req.headers['x-real-ip'] || req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '') as string;
    this.ip = String(fwd).split(',')[0].trim().slice(0, 45);
    this.userAgent = String(req.headers['user-agent'] || '').slice(0, 255);
    this.session = decodeSession(parseCookies(req.headers.cookie)[SESSION_COOKIE]);
  }

  async parseBody(): Promise<void> {
    if (['GET', 'HEAD', 'OPTIONS'].includes(this.method)) return;
    const ctype = String(this.req.headers['content-type'] || '').toLowerCase();
    let buf: Buffer;
    const preParsed = (this.req as any).body;
    if ((this.req.readableEnded || (this.req as any).complete) && preParsed !== undefined && !this.req.readable) {
      // The platform already consumed the stream and exposed `req.body`.
      if (Buffer.isBuffer(preParsed)) buf = preParsed;
      else if (typeof preParsed === 'string') buf = Buffer.from(preParsed);
      else if (ctype.includes('application/json')) buf = Buffer.from(JSON.stringify(preParsed));
      else buf = Buffer.from(new URLSearchParams(preParsed as Record<string, string>).toString());
    } else {
      buf = await readStream(this.req, 4 * 1024 * 1024 + 512 * 1024);
    }
    this.rawBody = buf;
    if (ctype.includes('application/json')) {
      try {
        this.json = buf.length ? JSON.parse(buf.toString('utf8')) : null;
      } catch {
        this.json = undefined; // invalid JSON
      }
    } else if (ctype.includes('multipart/form-data')) {
      const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(this.req.headers['content-type'] || '');
      const boundary = m ? m[1] || m[2] : '';
      if (boundary) {
        const { fields, files } = parseMultipart(buf, boundary);
        this.form = new Args(fields);
        this.files = files;
      }
    } else if (buf.length) {
      this.form = new Args(new URLSearchParams(buf.toString('utf8')));
    }
  }

  get raw(): Buffer | null {
    return this.rawBody;
  }

  // ── response helpers ──
  setOut(status: number, body: Buffer | string, type: string, headers: Record<string, string | string[]> = {}) {
    this.out = { status, body, headers: { 'Content-Type': type, ...headers } };
  }
  html(body: string, status = 200) {
    this.setOut(status, body, 'text/html; charset=utf-8', { 'Cache-Control': 'no-store' });
  }
  jsonOut(data: any, status = 200) {
    this.setOut(status, JSON.stringify(data), 'application/json; charset=utf-8', { 'Cache-Control': 'no-store' });
  }
  text(body: string, status = 200, type = 'text/plain; charset=utf-8') {
    this.setOut(status, body, type);
  }
  redirect(location: string, status = 302) {
    this.setOut(status, '', 'text/plain; charset=utf-8', { Location: location });
  }
  download(body: string, filename: string, type = 'text/csv; charset=utf-8') {
    this.setOut(200, body, type, { 'Content-Disposition': `attachment; filename=${filename}`, 'Cache-Control': 'no-store' });
  }

  // ── session helpers ──
  setSession(patch: Partial<SessionData> | null) {
    if (patch === null) this.session = {};
    else Object.assign(this.session, patch);
    this.sessionDirty = true;
  }
  flash(message: string, category = 'info') {
    const list = this.session.flashes || [];
    list.push([category, String(message).slice(0, 600)]);
    this.session.flashes = list.slice(-8);
    this.sessionDirty = true;
  }
  popFlashes(): [string, string][] {
    const list = this.session.flashes || [];
    if (list.length) {
      this.session.flashes = [];
      this.sessionDirty = true;
    }
    return list;
  }

  sessionCookie(): string | null {
    if (!this.sessionDirty) return null;
    const empty = !this.session.uid && !(this.session.flashes && this.session.flashes.length) && !this.session.reset;
    const base = `${SESSION_COOKIE}=`;
    const flags = `Path=/; HttpOnly; SameSite=Lax${config.secureCookies ? '; Secure' : ''}`;
    if (empty) return `${base}; ${flags}; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT`;
    const maxAge = config.sessionDays * 86400;
    const data: SessionData = { ...this.session, exp: Math.floor(Date.now() / 1000) + maxAge };
    return `${base}${encodeSession(data)}; ${flags}; Max-Age=${maxAge}`;
  }
}

// ───────────────────────────── router ─────────────────────────────

export type Handler = (c: Ctx) => Promise<void | boolean> | void | boolean;

interface Route {
  method: string;
  endpoint: string;
  regex: RegExp;
  keys: { name: string; type: string }[];
  pattern: string;
  handlers: Handler[];
}

const routes: Route[] = [];
const endpointPaths = new Map<string, string>();

function compile(pattern: string): { regex: RegExp; keys: { name: string; type: string }[] } {
  const keys: { name: string; type: string }[] = [];
  const src = pattern.replace(/[.*+?^${}()|[\]\\]/g, (m) => (m === '<' || m === '>' ? m : '\\' + m)).replace(/<(?:(int|string):)?([a-zA-Z_]+)>/g, (_m, type: string, name: string) => {
    keys.push({ name, type: type || 'string' });
    return type === 'int' ? '(\\d+)' : '([^/]+)';
  });
  return { regex: new RegExp('^' + src + '$'), keys };
}

/**
 * Register a route. `paths` may be a string or an array (the first is the canonical URL
 * used by `url_for`). Handlers run in order; a handler stops the chain by producing a
 * response (`c.redirect`, `c.html`, …) or by returning `false`.
 */
export function route(methods: string | string[], endpoint: string, paths: string | string[], ...handlers: Handler[]) {
  const list = Array.isArray(paths) ? paths : [paths];
  const ms = (Array.isArray(methods) ? methods : [methods]).map((m) => m.toUpperCase());
  if (!endpointPaths.has(endpoint)) endpointPaths.set(endpoint, list[0]);
  for (const p of list) {
    const { regex, keys } = compile(p);
    for (const m of ms) routes.push({ method: m, endpoint, regex, keys, pattern: p, handlers });
  }
}

export const GET = (endpoint: string, paths: string | string[], ...h: Handler[]) => route('GET', endpoint, paths, ...h);
export const POST = (endpoint: string, paths: string | string[], ...h: Handler[]) => route('POST', endpoint, paths, ...h);
export const ANY = (endpoint: string, paths: string | string[], ...h: Handler[]) => route(['GET', 'POST'], endpoint, paths, ...h);

/** Flask-compatible `url_for`. Unknown params become the query string. */
export function urlFor(endpoint: string, params: Record<string, any> = {}): string {
  if (endpoint === 'static') {
    return '/static/' + String(params.filename || '').replace(/^\/+/, '');
  }
  const pattern = endpointPaths.get(endpoint);
  if (!pattern) {
    console.warn(`[url_for] unknown endpoint: ${endpoint}`);
    return '#';
  }
  const used = new Set<string>();
  let path = pattern.replace(/<(?:(?:int|string):)?([a-zA-Z_]+)>/g, (_m, name: string) => {
    used.add(name);
    return encodeURIComponent(String(params[name] ?? ''));
  });
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (used.has(k) || k === '_external' || v === undefined || v === null) continue;
    q.append(k, String(v));
  }
  const qs = q.toString();
  return qs ? `${path}?${qs}` : path;
}

export function allEndpoints(): string[] {
  return [...endpointPaths.keys()];
}

export interface Match {
  route: Route;
  params: Record<string, any>;
}

export function matchRoute(method: string, path: string): { match?: Match; redirectTo?: string; methodNotAllowed?: boolean } {
  let pathMatched = false;
  const tryPath = (p: string): Match | undefined => {
    for (const r of routes) {
      const m = r.regex.exec(p);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method && !(method === 'HEAD' && r.method === 'GET')) continue;
      const params: Record<string, any> = {};
      r.keys.forEach((k, i) => {
        const raw = decodeURIComponent(m[i + 1]);
        params[k.name] = k.type === 'int' ? parseInt(raw, 10) : raw;
      });
      return { route: r, params };
    }
    return undefined;
  };
  const direct = tryPath(path);
  if (direct) return { match: direct };
  // Flask strict_slashes behaviour: "/agent" → "/agent/" when only the slash form exists.
  if (!path.endsWith('/')) {
    const m = tryPath(path + '/');
    if (m && m.route.pattern.endsWith('/')) return { redirectTo: path + '/' };
  }
  return { methodNotAllowed: pathMatched };
}

export type Middleware = (c: Ctx) => Promise<void> | void;
export type ErrorRenderer = (c: Ctx, err: unknown) => Promise<void> | void;

export interface DispatchOptions {
  before?: Middleware;
  onError?: ErrorRenderer;
  notFound?: Middleware;
}

export async function dispatch(req: IncomingMessage, res: ServerResponse, opts: DispatchOptions = {}): Promise<void> {
  const c = new Ctx(req, res);
  try {
    const found = matchRoute(c.method, c.path);
    if (found.redirectTo) {
      c.redirect(found.redirectTo + (c.url.search || ''), 308);
    } else {
      await c.parseBody();
      if (opts.before) await opts.before(c);
      if (!c.out) {
        if (!found.match) {
          if (found.methodNotAllowed) throw new HttpError(405);
          throw new HttpError(404);
        }
        c.params = found.match.params;
        c.endpoint = found.match.route.endpoint;
        for (const h of found.match.route.handlers) {
          const r = await h(c);
          if (c.out || r === false) break;
        }
        if (!c.out) throw new Error(`Handler for ${c.endpoint} produced no response`);
      }
    }
  } catch (err) {
    c.out = null;
    try {
      if (opts.onError) await opts.onError(c, err);
    } catch (err2) {
      console.error('[error handler failed]', err2);
    }
    if (!c.out) {
      const status = err instanceof HttpError ? err.status : 500;
      c.text(status === 404 ? 'Not found' : 'Internal server error', status);
    }
  }
  send(c);
}

function send(c: Ctx) {
  const out = c.out!;
  const headers: Record<string, string | string[]> = { ...out.headers };
  const cookie = c.sessionCookie();
  if (cookie) headers['Set-Cookie'] = cookie;
  headers['X-Content-Type-Options'] = 'nosniff';
  headers['X-Frame-Options'] = 'SAMEORIGIN';
  headers['Referrer-Policy'] = 'same-origin';
  const body = typeof out.body === 'string' ? Buffer.from(out.body) : out.body;
  headers['Content-Length'] = String(body.length);
  c.res.writeHead(out.status, headers as any);
  c.res.end(c.method === 'HEAD' ? undefined : body);
}
