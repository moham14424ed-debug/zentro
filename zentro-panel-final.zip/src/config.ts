/** Central configuration, read once from environment variables. */

const env = process.env;

function normalizeDatabaseUrl(raw: string | undefined): string {
  if (!raw) return '';
  let url = raw.trim();
  // Old Flask/SQLAlchemy style URLs: postgresql+psycopg2://, postgresql+psycopg://
  url = url.replace(/^postgres(?:ql)?\+[a-z0-9_]+:\/\//i, 'postgresql://');
  url = url.replace(/^postgres:\/\//i, 'postgresql://');
  return url;
}

export const isProduction = env.NODE_ENV === 'production' || !!env.VERCEL;

export const config = {
  secretKey: env.SECRET_KEY || env.JWT_SECRET || '',
  databaseUrl: normalizeDatabaseUrl(
    env.SUPABASE_DATABASE_URL || env.DATABASE_URL || env.POSTGRES_URL || env.POSTGRES_URL_NON_POOLING,
  ),
  adminPassword: env.ADMIN_PASSWORD || '',
  testPassword: env.TEST_PASSWORD || 'test123',
  cronSecret: env.CRON_SECRET || '',
  axionelUrl: env.AXIONEL_API_URL || 'https://axionel.stats.direct/rest/sms',
  axionelUsername: env.AXIONEL_API_USERNAME || '',
  axionelPassword: env.AXIONEL_API_PASSWORD || '',
  axionelFetchInterval: Math.max(parseInt(env.AXIONEL_FETCH_INTERVAL || '15', 10) || 15, 15),
  webhookSecret: env.SMS_WEBHOOK_SECRET || '',
  /** Auto-return of idle numbers is OFF unless AUTO_RETURN_ENABLED=true (it would also take back numbers users requested by themselves). */
  autoReturnEnabled: env.AUTO_RETURN_ENABLED === 'true',
  autoReturnAfterHours: Math.max(parseFloat(env.AUTO_RETURN_AFTER_HOURS || '1') || 1, 0.25),
  autoReturnMinSms: Math.max(parseInt(env.AUTO_RETURN_MIN_SMS || '20', 10) || 0, 0),
  sessionDays: 7,
  loginAttemptLimit: 5,
  lockMinutes: 15,
  secureCookies: isProduction && env.SESSION_COOKIE_SECURE !== 'false',
  /** Minimum seconds between two fetches of the same provider. */
  minFetchInterval: 15,
};

/** Returns a list of missing mandatory settings (empty when everything is fine). */
export function missingConfig(): string[] {
  const missing: string[] = [];
  if (!config.databaseUrl) missing.push('DATABASE_URL (Supabase pooler connection string)');
  if (!config.secretKey) missing.push('SECRET_KEY (long random string)');
  if (!config.axionelUsername) missing.push('AXIONEL_API_USERNAME');
  if (!config.axionelPassword) missing.push('AXIONEL_API_PASSWORD');
  else if (isProduction && config.secretKey.length < 16) missing.push('SECRET_KEY must be at least 16 characters');
  return missing;
}
