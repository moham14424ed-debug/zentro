# ZENTRO PANEL — branding and interface refresh

## Approved scope
- Rename all user-facing VeroSMS branding to ZENTRO PANEL.
- Use the supplied ZENTRO logo throughout the application.
- Refresh the shared UI into a dark, mobile-friendly SMS operations dashboard with electric-blue accents, clear status chips, dense data tables, and a compact navigation shell.
- Preserve existing routes, permissions, database schema, provider logic, and business rules.
- Use Lamix/IMS only as visual and information-architecture references; do not copy their code or private data.

## Design
- **Movement:** dark control-room dashboard with cyber-blue telemetry accents.
- **Core principles:** operational clarity, high contrast, compact data density, and mobile-first controls.
- **Color philosophy:** near-black navy surfaces make the supplied blue logo and status colors legible; cyan/blue signals availability and system activity while amber/red remain reserved for warnings.
- **Layout paradigm:** persistent top navigation with grouped operational menus and wide data surfaces that collapse cleanly on phones.
- **Signature elements:** blue edge glow, logo-backed brand mark, and pill status indicators.
- **Interaction:** actions remain explicit and reversible; tables retain familiar filters and export controls.
- **Typography:** Arial/system sans for reliable rendering, with bold uppercase utility labels and regular sentence-case content.
- **Brand essence:** global SMS number operations for teams that need a clear, dependable control panel; precise, modern, direct.

## Project structure
- `views/base.html`: shared navigation, theme tokens, footer, and global responsive styling.
- `views/auth/login.html`: branded login experience.
- `public/static/img/zentro-panel.png`: supplied logo asset.
- `src/generated/assets.ts`: generated template bundle, refreshed by `npm run generate`.
