# ZENTRO PANEL refresh

- [x] Rename user-facing VeroSMS branding to ZENTRO PANEL without changing route names or database behavior.
- [x] Replace the old logo references with the supplied ZENTRO logo in the shell and login page.
- [x] Apply the dark ZENTRO theme to the shared shell, navigation, cards, tables, forms, alerts, and mobile breakpoints.
- [x] Preserve existing provider, OTP, user, range, and number-management permissions.
- [x] Run asset generation and TypeScript validation, then package the updated project.

- [x] Add direct per-range requests with stock/quota visibility and atomic allocation.
- [x] Add client-side number selection, return-to-pool, filtering, pagination, and CSV management.
- [x] Preserve agent bulk assign/unassign/return controls and admin quota management.
