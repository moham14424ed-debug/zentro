# ZENTRO on Vercel with Axionel

This build uses only the Axionel REST SMS provider. Old IMS/panel provider records are deleted automatically on startup; OTP history remains because its provider reference is nullable. Provider credentials are read only from environment variables.

## Required Vercel environment variables

Set these for **Production**, **Preview**, and **Development** as needed:

```text
DATABASE_URL=your PostgreSQL connection string
SECRET_KEY=a-long-random-secret-at-least-32-characters
ADMIN_PASSWORD=your-admin-password
TEST_PASSWORD=test123
AXIONEL_API_URL=https://axionel.stats.direct/rest/sms
AXIONEL_API_USERNAME=zentro
AXIONEL_API_PASSWORD=your-Axionel-password
AXIONEL_FETCH_INTERVAL=15
CRON_SECRET=a-second-long-random-secret
```

Do not put these values in frontend JavaScript or commit them to GitHub.

## Deploy/update without deleting the old project

1. Open the existing project in Vercel.
2. Go to **Settings → Environment Variables** and add the variables above.
3. Make sure `DATABASE_URL` points to the same PostgreSQL database used by the existing panel.
4. Upload the updated project to the same Git repository or deploy the new commit from Vercel.
5. Click **Redeploy** and choose **Use existing Build Cache** only if dependencies are unchanged; otherwise redeploy without cache.
6. On the first request, the migration creates the Axionel provider and removes old provider records.

## OTP polling on the free Vercel plan

The panel polls while a user has a page open through `/api/tick`. Vercel Hobby Cron is limited to one run per day, so it cannot provide a 15-second background worker by itself. The project keeps the daily Vercel cron as a backup. For near-real-time polling without buying a backend host, create a free monitor at `https://cron-job.org/` that sends a GET request every minute to:

```text
https://YOUR-DOMAIN.vercel.app/api/cron/run
```

Send this header:

```text
Authorization: Bearer YOUR_CRON_SECRET
```

The endpoint is idempotent: multiple invocations are safe, messages are deduplicated, and each message is assigned by `destination_addr` to the matching number in the panel.

## Important provider limitation

Axionel currently exposes pagination but did not accept the tested date filters. The integration reads the newest pages, stores a last-message marker, stops when it reaches that marker, and caps one invocation at 20 pages (2,000 messages). If the provider can receive more than 2,000 messages between polls, ask Axionel for a cursor, `since_id`, `start_stamp` filter, or webhook to eliminate any possible gap.
