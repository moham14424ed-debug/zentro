/**
 * End-to-end smoke test against a running server (`npm run dev` + a database).
 *   BASE=http://localhost:3000 ADMIN_PASSWORD=... npx tsx scripts/smoke-test.ts
 * Logs in as admin, creates a range / agent / client, exercises the per-user limit flow and crawls every page.
 */
import { Client } from '../src/fetchers/client';

const BASE = (process.env.BASE || 'http://localhost:3000').replace(/\/$/, '');
const ADMIN_PW = process.env.ADMIN_PASSWORD || '';
let failures = 0;
let lastFlash = '';
const ok = (cond: any, msg: string) => {
  if (!cond) { failures++; console.log('  ✗ FAIL:', msg, lastFlash ? '| last message: ' + lastFlash : ''); } else console.log('  ✓', msg);
};

class Session {
  c = new Client();
  constructor(public name: string) {}
  get(path: string) { return this.c.get(BASE + path, { timeout: 30000 }); }
  async post(path: string, form: Record<string, any> = {}) {
    const r = await this.c.post(BASE + path, { form, headers: { Origin: BASE, Referer: BASE + '/' }, timeout: 30000 });
    lastFlash = [...r.text.matchAll(/<div class="alert alert-\w+">([^]*?)<button/g)].map((m) => m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()).join(' || ');
    return r;
  }
  async login(username: string, password: string) {
    const page = await this.get('/login');
    const m = page.text.match(/What is (\d+) \+ (\d+)/);
    const h = (n: string) => page.text.match(new RegExp(`name="${n}" value="([^"]*)"`))?.[1] ?? '';
    const r = await this.post('/login', { username, password, capt: m ? +m[1] + +m[2] : 0, captcha_num1: h('captcha_num1'), captcha_num2: h('captcha_num2'), captcha_exp: h('captcha_exp'), captcha_sig: h('captcha_sig') });
    return r;
  }
  /** GETs a page and reports obvious template/route problems. */
  async crawl(path: string) {
    const r = await this.get(path);
    const bad = [/\[url_for\]/, /Traceback/, /\[object Object\]/, /TemplateError/, />undefined</, />NaN</].find((re) => re.test(r.text));
    ok(r.status === 200 && !bad, `${this.name} GET ${path} -> ${r.status}${bad ? ' (suspicious output ' + bad + ')' : ''}`);
    return r;
  }
}

async function main() {
  const admin = new Session('admin');
  let r = await admin.login('admin', ADMIN_PW);
  ok(r.url.endsWith('/agent/dashboard') || r.url.endsWith('/') || r.text.includes('Dashboard'), 'admin login');

  const tag = Date.now().toString().slice(-6);
  const prefix = '249' + tag;
  const nums = Array.from({ length: 60 }, (_, i) => prefix + String(100000 + i)).join('\n');

  console.log('\n== create range with numbers ==');
  r = await admin.post('/admin/ranges/create', { name: 'Smoke ' + tag, prefix, country: 'Sudan', payout: '0.01', daily_limit: '50', application: '', numbers_text: nums, test_number: '' });
  ok(/created with 60 numbers/.test(r.text), 'range created with 60 numbers + test pool');
  const rid = Number((await admin.get('/admin/ranges?search=' + prefix)).text.match(/\/admin\/ranges\/(\d+)\/edit/)?.[1]);
  ok(rid > 0, 'range id found: ' + rid);

  r = await admin.post(`/admin/ranges/${rid}/add-numbers`, { numbers_text: Array.from({ length: 10 }, (_, i) => prefix + String(200000 + i)).join('\n') + '\n' + prefix + '100000' });
  ok(/10 numbers added/.test(r.text) && /skipped/.test(r.text), 'add numbers to existing range (10 new, duplicate skipped)');

  console.log('\n== users ==');
  const roles = await admin.get('/admin/users/create');
  const roleId = (name: string) => Number(roles.text.match(new RegExp(`value="(\\d+)"[^>]*>\\s*${name}`, 'i'))?.[1]);
  const agentRole = roleId('Agent'), clientRole = roleId('Client');
  ok(agentRole > 0 && clientRole > 0, `role ids agent=${agentRole} client=${clientRole}`);
  const mk = async (u: string, role: number) => {
    const x = await admin.post('/admin/users/create', { username: u, email: `${u}@x.test`, password: 'Passw0rd!', role_id: role, name: u });
    ok(/created successfully/.test(x.text), 'created user ' + u);
    return Number(x.text.match(new RegExp(`/admin/users/view/(\\d+)[^]*?${u}`))?.[1] || x.text.match(new RegExp(`${u}[^]*?/admin/users/(\\d+)/limits`))?.[1]);
  };
  const agentName = 'agent' + tag, clientName = 'client' + tag;
  await mk(agentName, agentRole);
  await mk(clientName, clientRole);
  const list = await admin.get('/admin/users?search=' + tag);
  const idOf = (u: string) => Number(list.text.match(new RegExp(`/admin/users/view/(\\d+)"[^>]*>[^<]*${u}|${u}[^]*?/admin/users/(\\d+)/`))?.slice(1).find(Boolean));
  const agentId = idOf(agentName), clientId = idOf(clientName);
  ok(agentId > 0 && clientId > 0, `user ids agent=${agentId} client=${clientId}`);

  console.log('\n== admin gives numbers directly ==');
  r = await admin.post(`/admin/users/${agentId}/add-number`, { range_id: rid, numbers_count: 5 });
  ok(/5 numbers added/.test(r.text), 'admin added 5 numbers to agent');

  console.log('\n== per-user limits ==');
  r = await admin.post(`/admin/users/${agentId}/limits`, { [`limit_${rid}`]: 20 });
  ok(/range limit\(s\) saved/.test(r.text), 'limit 20 saved for agent');
  r = await admin.post(`/admin/users/${clientId}/limits`, { [`limit_${rid}`]: 7 });
  ok(/range limit\(s\) saved/.test(r.text), 'limit 7 saved for client');

  const agent = new Session('agent');
  r = await agent.login(agentName, 'Passw0rd!');
  ok(r.text.includes('Dashboard'), 'agent login');
  let rn = await agent.crawl('/agent/request-numbers');
  ok(/Request/.test(rn.text) && rn.text.includes('20'), 'agent sees limit 20');
  r = await agent.post('/agent/request-numbers', { range_id: rid, numbers_count: 12 });
  ok(/12 numbers added/.test(r.text) && /Remaining limit on this range: 8/.test(r.text), 'agent took 12 random numbers (8 left)');
  r = await agent.post('/agent/request-numbers', { range_id: rid, numbers_count: 50 });
  ok(/only 8 were allowed/.test(r.text), 'request clamped to remaining limit (8)');
  r = await agent.post('/agent/request-numbers', { range_id: rid, numbers_count: 1 });
  ok(/limit|Remaining|not allowed|exhaust|used/i.test(r.text) && !/numbers added/.test(r.text), 'no more numbers once the limit is used up');
  const mine = await agent.crawl('/agent/my-numbers');
  ok(/total/i.test(mine.text), 'agent my-numbers page');

  r = await agent.post(`/agent/request-limit/${rid}`, { note: 'need 50 more' });
  ok(/sent to the administrator/.test(r.text), 'agent asked admin for more');
  r = await admin.post(`/admin/users/${agentId}/limits`, { action: 'increase', range_id: rid, amount: 30 });
  ok(/increased by 30/.test(r.text), 'admin increased limit by 30');
  r = await agent.post('/agent/request-numbers', { range_id: rid, numbers_count: 10 });
  ok(/10 numbers added/.test(r.text), 'agent could take 10 more after increase');

  const client = new Session('client');
  r = await client.login(clientName, 'Passw0rd!');
  ok(r.text.includes('Dashboard'), 'client login');
  r = await client.post('/agent/request-numbers', { range_id: rid, numbers_count: 100 });
  ok(/7 numbers added/.test(r.text) || /only 7/.test(r.text), 'client got exactly its limit (7)');
  r = await agent.post('/agent/request-numbers', { range_id: 999999, numbers_count: 1 });
  ok(/not available|select a range|Invalid/i.test(r.text), 'invalid range rejected');

  console.log('\n== OTP flow via webhook ==');
  const myNum = (await admin.get(`/admin/sms/numbers?agent=${agentId}`)).text.match(new RegExp(`${prefix}\\d{6}`))?.[0];
  ok(!!myNum, 'found an agent number ' + myNum);
  const hook = await fetch(BASE + '/api/sms/receive', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Webhook-Secret': process.env.SMS_WEBHOOK_SECRET || 'x' }, body: JSON.stringify({ number: myNum, from: 'WhatsApp', message: 'Your code is 123456' }) });
  ok(hook.status === 200 || (!process.env.SMS_WEBHOOK_SECRET && hook.status === 401), 'webhook accepted with secret (' + hook.status + ')');
  const noSecret = await fetch(BASE + '/api/sms/receive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  ok(noSecret.status === 401 || noSecret.status === 503, 'webhook rejects calls without the secret');

  console.log('\n== crawl pages ==');
  for (const p of ['/agent/dashboard', '/agent/api-docs', '/agent/Notifications', '/agent/SMSRanges', '/agent/SMSTestPanel', '/agent/SMSCDRReports', '/agent/Clients', '/agent/CreateClient', '/agent/Profile', '/agent/MyActivity', '/agent/request-numbers',
    '/agent/otp-inbox', '/agent/BankAccounts', '/agent/PaymentRequests', '/agent/CreditNotes', '/agent/Statements', '/agent/my-numbers', '/agent/clients', '/agent/create-client',
    '/admin/', '/admin/users', '/admin/users/create', `/admin/users/view/${agentId}`, `/admin/users/${agentId}/edit`, `/admin/users/${agentId}/add-number`, `/admin/users/${agentId}/limits`, '/admin/users/import-backup', '/admin/api-access',
    '/admin/ranges', '/admin/ranges/create', `/admin/ranges/${rid}/edit`, '/admin/sms/numbers', '/admin/sms/numbers/return?agent_id=' + agentId, '/admin/sms/cdr', '/admin/activity', '/admin/news', '/admin/news/create',
    '/admin/agent-limits', '/admin/agent-otp-stats', '/admin/add-numbers-to-agent', '/admin/providers', '/admin/providers/add', '/admin/otp-logs', '/admin/BankAccounts', '/admin/PaymentRequests', '/admin/CreditNotes',
    '/monitor/', '/dev/', '/dev/upload', '/dev/pages/', '/agent/dashboard?x=1']) await admin.crawl(p);
  for (const p of ['/agent/dashboard', '/agent/MyAssignedNumbers', '/agent/SMSRanges', '/agent/SMSTestPanel', '/agent/SMSCDRReports', '/agent/request-numbers', '/agent/otp-inbox', '/agent/Profile', '/agent/MyActivity', '/agent/api-docs', '/agent/Notifications']) await client.crawl(p);
  for (const p of ['/agent/dashboard', '/agent/my-numbers', '/agent/Clients']) await agent.crawl(p);

  console.log('\n== permissions ==');
  for (const p of ['/admin/', '/admin/users', '/admin/providers', '/admin/ranges']) { const x = await agent.get(p); ok(!x.url.includes('/admin/') || x.status === 403 || x.url.includes('dashboard'), `agent blocked from ${p}`); }
  const anon = new Session('anon');
  const a = await anon.get('/agent/dashboard');
  ok(a.url.includes('/login'), 'anonymous redirected to login');
  const csrf = await fetch(BASE + '/admin/users/1/delete', { method: 'POST', headers: { Origin: 'https://evil.example' } });
  ok(csrf.status === 403 || csrf.status === 302, 'cross-site POST refused/redirected (' + csrf.status + ')');

  console.log('\n== cron ==');
  const cr = await fetch(BASE + '/api/cron/run', { headers: { Authorization: 'Bearer ' + (process.env.CRON_SECRET || 'x') } });
  ok(cr.status === 200 || !process.env.CRON_SECRET, 'cron endpoint (' + cr.status + ')');
  const cr2 = await fetch(BASE + '/api/cron/run');
  ok(cr2.status === 401 || cr2.status === 403, 'cron endpoint rejects anonymous');

  console.log(failures ? `\n${failures} check(s) FAILED` : '\nAll checks passed');
  process.exit(failures ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
