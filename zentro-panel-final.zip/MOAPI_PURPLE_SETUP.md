# MOAPI Purple setup

The provider uses a token, not a username/password.

## Add it from the admin panel

1. Open **Admin → Providers → Add Provider**.
2. Choose the preset **MOAPI Purple**.
3. Put the token from your provider administrator in **Secret / Password / Token**.
4. Keep the API URL:

```text
http://137.74.1.203/crapi/reseller/mdr.php
```

5. Keep these values:

```text
Type: API / JSON
Authentication: Token / custom fields
Request Method: GET
Payload Location: URL query parameters
Response Data Path: data
Number field: number
Sender field: cli
Message field: message
Date field: datetime
```

6. Save the provider. The panel automatically requests the previous UTC day through the current UTC day using:

```json
{
  "token": "{{token}}",
  "fromdate": "{{fromdate}}",
  "todate": "{{todate}}",
  "searchnumber": "",
  "searchcli": "",
  "records": "200"
}
```

`{{token}}` is replaced by the saved token, `{{fromdate}}` by yesterday at `00:00:00`, and `{{todate}}` by today at `23:59:59`.

## Important

Do not put the token in the URL sent to users or in frontend JavaScript. Save it only in the provider form on the server. The provider supports up to 200 records per request according to the supplied API guide. If more than 200 messages can arrive during one polling window, ask the provider for pagination or a date-range filter with a smaller interval.
