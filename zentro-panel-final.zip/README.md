# ZENTRO PANEL — Vercel (free plan) edition

لوحة إدارة أرقام/OTP مكتوبة بـ **TypeScript** (بدون Flask) وتعمل على **Vercel Hobby المجاني** مع قاعدة **Supabase Postgres**.
A TypeScript rewrite of the old Flask panel. One serverless function (`api/index.ts`) serves everything; no framework needed.

## النشر / Deploy (10 دقائق)

1. **Supabase**: Project Settings → Database → Connection string → **Transaction pooler** (port 6543). انسخ الرابط (الرابط المباشر `db.xxx.supabase.co` لا يعمل على Vercel لأنه IPv6 فقط).
2. ارفع المجلد إلى GitHub ثم **Vercel → Add New → Project → Import**. لا تغيّر أي إعدادات (Framework: Other).
3. **Environment Variables** على Vercel:

| Name | Value |
|---|---|
| `DATABASE_URL` | رابط الـ pooler من Supabase |
| `SECRET_KEY` | نص عشوائي طويل (`openssl rand -hex 32`) |
| `ADMIN_PASSWORD` | كلمة مرور المدير الأول (اسم المستخدم `admin`) |
| `CRON_SECRET` | نص عشوائي لحماية `/api/cron/*` |
| `SMS_WEBHOOK_SECRET` | (اختياري) لتفعيل `POST /api/sms/receive` |

4. Deploy. الجداول تُنشأ/تُرقّى تلقائياً أول مرة (تعمل أيضاً فوق قاعدة Supabase القديمة بدون فقدان بيانات).
5. للجلب السريع من الـ providers (كل 5 دقائق) ضع في GitHub secrets: `APP_URL` و `CRON_SECRET` — ملف `.github/workflows/poll.yml` جاهز. بدونه: يجلب أثناء فتح أي صفحة من اللوحة (كل ~30 ثانية) + cron يومي من Vercel.

## الميزة الجديدة: طلب الأرقام بالليميت / self-service numbers

- المدير: **Users → Limits** يحدد لكل مستخدم ولكل Range كم رقماً يستطيع أن يأخذه بنفسه (0 = ممنوع). أو من **Ranges → Limit** لتطبيق نفس الرقم على كل الوكلاء/العملاء.
- المستخدم: **Numbers → Request Numbers** → يضغط *Request* فيحصل فوراً على أرقام **عشوائية** من نفس الـ Range (حتى الليميت المتبقي). 
- إذا انتهى الليميت يضغط *Ask admin for more* فيصل الطلب للمدير في **Overview** ويزيده بضغطة واحدة.
- نفس الشيء عبر الـ API: `POST /api/sms/numbers/request {range_id, quantity}` و `GET /api/sms/limits`.

## ما الذي تغيّر عن النسخة القديمة

- حذف Flask وكل ما يخص MGO/MDO/MSI (اللوحة المدمجة Panel4 وبياناتها الثابتة، الشعارات، ملفات النشر القديمة).
- إصلاح إضافة الـ Ranges (إدراج جماعي سريع، تجاوز المكرر، بركة الاختبار) وإضافة الأرقام للمستخدمين (قفل `SKIP LOCKED` فلا يتكرر رقم).
- أمان: جلسات موقّعة + كابتشا موقّعة + قفل محاولات الدخول + حماية CSRF + إعادة تعيين كلمة المرور للعملاء فقط + منع السحب المزدوج للأرصدة.
- إزالة ثغرات الـ API القديمة: كان بالإمكان إنشاء أرباح وهمية (`/sms/send`, `/sms/scr`) وتوليد أرقام من العدم (`/sms/numbers/request`)، وwebhook مفتوح للجميع.

## تشغيل محلي
```
npm install
cp .env.example .env   # عدّل القيم ثم export للمتغيرات
npm run dev
BASE=http://localhost:3000 ADMIN_PASSWORD=... npm run smoke   # اختبار شامل
```
حدود الخطة المجانية: جسم الطلب ≤ 4.5MB (ارفع ملفات الأرقام الكبيرة على دفعات)، الدالة ≤ 60 ثانية، cron يومي واحد.
